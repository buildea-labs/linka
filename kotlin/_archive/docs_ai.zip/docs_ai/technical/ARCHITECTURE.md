# Architecture Overview

## Objective

This document details the architecture of the Linka Android Kotlin application, enriched with actual file paths and component mappings based on the project structure, marking inferred paths for human validation.

## Responsibilities and Layers

The architecture follows a layered, modular approach:

-   **Application Entry Point**:
    -   **File**: `linka-android-kotlin/app/src/main/kotlin/com/linka/app/LinkaApp.kt` (*Standard Android Application class path, necessita validação humana para confirmação exata*)
    -   **Role**: Initializes the application, sets up DI, and launches the main UI.

-   **Presentation Layer**:
    -   **UI Composables**: Located within feature module `ui/` directories.
        -   Example: `linka-android-kotlin/featureHome/src/main/kotlin/.../ui/HomeScreen.kt` (*necessita validação humana para nome exato do arquivo*)
        -   Example: `linka-android-kotlin/featureDiagnostico/src/main/kotlin/.../ui/DiagnosticScreen.kt` (*necessita validação humana*)
    -   **ViewModels**: Manage UI state.
        -   Example: `linka-android-kotlin/featureHome/src/main/kotlin/.../ui/HomeViewModel.kt` (*necessita validação humana*)
        -   Example: `linka-android-kotlin/featureDiagnostico/src/main/kotlin/.../ui/DiagnosticViewModel.kt` (*necessita validação humana*)

-   **Domain/Data Layer**:
    -   **Repositories**: Abstract data sources.
        -   Example: `linka-android-kotlin/coreNetwork/src/main/kotlin/.../data/DeviceRepository.kt` (*inferential path, necessita validação humana*)
        -   Example: `linka-android-kotlin/featureDevices/src/main/kotlin/.../data/DeviceRepository.kt` (*inferential path, necessita validação humana*)
    -   **Data Sources**: Concrete implementations.
        -   **Network**: Interface likely in `linka-android-kotlin/coreNetwork/src/main/kotlin/.../api/ApiService.kt` (*necessita validação humana*). Service for AI worker: `AiDiagnosisService.kt` (*inferential path, necessita validação humana*).
        -   **Database**: DAOs likely in `linka-android-kotlin/coreDatabase/src/main/kotlin/.../dao/` (e.g., `DeviceDao.kt`, `HistoryDao.kt` - *necessita validação humana*).
        -   **DataStore**: Accessors likely in `linka-android-kotlin/coreDatastore/src/main/kotlin/.../` (e.g., `UserPreferencesDataSource.kt` - *inferential path, necessita validação humana*).

-   **Core Modules**: Provide shared functionalities.
    -   `linka-android-kotlin/coreDatabase/`: Database operations.
    -   `linka-android-kotlin/coreDatastore/`: Key-value storage.
    -   `linka-android-kotlin/coreNetwork/`: Network communication.
    -   `linka-android-kotlin/corePermissions/`: Permission management.
    -   `linka-android-kotlin/coreTelephony/`: Telephony services.

-   **Feature Modules**: Encapsulate specific functionalities (e.g., `linka-android-kotlin/featureDevices/`, `linka-android-kotlin/featureSpeedtest/`, `linka-android-kotlin/featureDiagnostico/`).

## Flow

A typical interaction flow:
1.  **User Action** -> **Composable UI** (`feature*/ui/`)
2.  **UI Event** -> **ViewModel** (`feature*/ui/*ViewModel.kt`)
3.  **ViewModel** -> **Repository** (e.g., `core*/data/*Repository.kt`)
4.  **Repository** -> **Data Sources** (`coreNetwork/api/*ApiService.kt`, `coreDatabase/dao/*Dao.kt`, `coreDatastore/*DataSource.kt`)
5.  **Data Sources** -> **Repository** (processed data)
6.  **Repository** -> **ViewModel** (updated state)
7.  **ViewModel** -> **UI State (`StateFlow`/`LiveData`)**
8.  **UI State** -> **Composable UI** (recomposition/update)

## Dependencies

-   **Jetpack Compose**: For UI.
-   **Kotlin Coroutines**: For async operations.
-   **Jetpack ViewModel**: For state management.
-   **Jetpack Room / DataStore**: For local persistence (`coreDatabase/`, `coreDatastore/`).
-   **Retrofit/Ktor (inferred)**: For network requests (`coreNetwork/api/`).
-   **Cloudflare Workers**: For AI backend (`cloudflare/ai-diagnosis-worker/wrangler.toml`).

## Critical Points

-   **Modularity**: Project divided into feature and core modules.
-   **Separation of Concerns**: Clear division between UI, state, business logic, and data access.
-   **AI Integration**: `coreNetwork/` service interacts with `cloudflare/ai-diagnosis-worker`.

## Known Risks

-   Exact package structures and file names for ViewModels, Repositories, Data Sources, and Service interfaces are inferential and require human validation.
-   The specific DI framework used is not identifiable from the structure and requires human validation.
-   The choice and implementation details of network client libraries (Retrofit/Ktor) need confirmation.
