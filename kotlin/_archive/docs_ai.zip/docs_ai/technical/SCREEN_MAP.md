# Screen Map

## Objective

This document maps the primary screens and their associated ViewModels to their respective feature modules within the Linka Android Kotlin application.

## Screen Mappings by Feature Module

-   **`app` Module**:
    -   **Main Entry Point**: `linka-android-kotlin/app/src/main/kotlin/com/linka/app/LinkaApp.kt` (Application class)
    -   **Top-Level UI**: Likely managed within `linka-android-kotlin/app/ui/` for navigation host and main theming. (*Inferential path*)

-   **`featureDevices` Module**:
    -   **Primary Screen**: `linka-android-kotlin/featureDevices/src/main/kotlin/com/linka/featuredevices/ui/DeviceListScreen.kt` (*Inferential path*)
    -   **ViewModel**: `linka-android-kotlin/featureDevices/src/main/kotlin/com/linka/featuredevices/ui/DeviceListViewModel.kt` (*Inferential path*)
    -   *Other screens (e.g., Detail) may exist within `featureDevices/ui/`.*

-   **`featureDiagnostico` Module**:
    -   **Primary Screen**: `linka-android-kotlin/featureDiagnostico/src/main/kotlin/com/linka/featurediagnostico/ui/DiagnosticScreen.kt` (*Inferential path*)
    -   **ViewModel**: `linka-android-kotlin/featureDiagnostico/src/main/kotlin/com/linka/featurediagnostico/ui/DiagnosticViewModel.kt` (*Inferential path*)

-   **`featureDns` Module**:
    -   **Primary Screen**: `linka-android-kotlin/featureDns/src/main/kotlin/com/linka/featuredns/ui/DnsScreen.kt` (*Inferential path*)
    -   **ViewModel**: `linka-android-kotlin/featureDns/src/main/kotlin/com/linka/featuredns/ui/DnsViewModel.kt` (*Inferential path*)

-   **`featureFibra` Module**:
    -   **Primary Screen**: `linka-android-kotlin/featureFibra/src/main/kotlin/com/linka/featurefibra/ui/FibraScreen.kt` (*Inferential path*)
    -   **ViewModel**: `linka-android-kotlin/featureFibra/src/main/kotlin/com/linka/featurefibra/ui/FibraViewModel.kt` (*Inferential path*)
    -   *Specific implementation requires human validation.*

-   **`featureHistory` Module**:
    -   **Primary Screen**: `linka-android-kotlin/featureHistory/src/main/kotlin/com/linka/featurehistory/ui/HistoryScreen.kt` (*Inferential path*)
    -   **ViewModel**: `linka-android-kotlin/featureHistory/src/main/kotlin/com/linka/featurehistory/ui/HistoryViewModel.kt` (*Inferential path*)

-   **`featureHome` Module**:
    -   **Primary Screen**: `linka-android-kotlin/featureHome/src/main/kotlin/com/linka/featurehome/ui/HomeScreen.kt` (*Inferential path*)
    -   **ViewModel**: `linka-android-kotlin/featureHome/src/main/kotlin/com/linka/featurehome/ui/HomeViewModel.kt` (*Inferential path*)

-   **`featureSettings` Module**:
    -   **Primary Screen**: `linka-android-kotlin/featureSettings/src/main/kotlin/com/linka/featuresettings/ui/SettingsScreen.kt` (*Inferential path*)
    -   **ViewModel**: `linka-android-kotlin/featureSettings/src/main/kotlin/com/linka/featuresettings/ui/SettingsViewModel.kt` (*Inferential path*)

-   **`featureSpeedtest` Module**:
    -   **Primary Screen**: `linka-android-kotlin/featureSpeedtest/src/main/kotlin/com/linka/featurespeedtest/ui/SpeedtestScreen.kt` (*Inferential path*)
    -   **ViewModel**: `linka-android-kotlin/featureSpeedtest/src/main/kotlin/com/linka/featurespeedtest/ui/SpeedtestViewModel.kt` (*Inferential path*)

-   **`featureWifi` Module**:
    -   **Primary Screen**: `linka-android-kotlin/featureWifi/src/main/kotlin/com/linka/featurewifi/ui/WifiScreen.kt` (*Inferential path*)
    -   **ViewModel**: `linka-android-kotlin/featureWifi/src/main/kotlin/com/linka/featurewifi/ui/WifiViewModel.kt` (*Inferential path*)

## Key Files/Modules

-   Feature module directories (`feature*`).
-   `ui/` sub-directory within feature modules for screens and ViewModels.
-   `app/` module for application-level setup and main navigation.

## Known Risks

-   Specific file paths and naming conventions for screens and ViewModels are inferential and require human validation.
-   The existence and primary screen/ViewModel for `featureFibra` need confirmation.
-   Navigation logic and how screens are composed via `NavController` need detailed review.
