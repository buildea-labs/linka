# Storage Mechanisms

## Objective

This document details the storage mechanisms used by the Linka Android Kotlin application, mapping concrete modules and inferred file paths.

## Storage Types and Mappings

The application employs multiple storage solutions:

### 1. Local Database (`coreDatabase`)

-   **Module Path**: `linka-android-kotlin/coreDatabase/`
-   **Technology (Inferred)**: Jetpack Room.
-   **Key Components**:
    -   DAO Interfaces: e.g., `linka-android-kotlin/coreDatabase/src/main/kotlin/.../dao/DeviceDao.kt` (*necessita validação humana*), `.../dao/HistoryDao.kt` (*necessita validação humana*).
    -   Room Database Class: e.g., `linka-android-kotlin/coreDatabase/src/main/kotlin/.../AppDatabase.kt` (*necessita validação humana*).
-   **Purpose**: Storing structured relational data (device info, logs, user data).

### 2. Key-Value Storage (`coreDatastore`)

-   **Module Path**: `linka-android-kotlin/coreDatastore/`
-   **Technology (Inferred)**: Jetpack DataStore.
-   **Key Components**: Data access classes, e.g., `linka-android-kotlin/coreDatastore/src/main/kotlin/.../UserPreferencesDataSource.kt` (*necessita validação humana*), `.../AppSettingsDataSource.kt` (*necessita validação humana*).
-   **Purpose**: Storing user preferences, settings, flags.

### 3. Temporary Storage

-   **Locations**:
    -   `linka-android-kotlin/tmp/`
    -   `linka-android-kotlin/source/tmp/`
-   **Inferred Contents**: Temporary files, caches, logs (e.g., `.tmp_linka.sqlite`, `.tmp_speedtest_leveldb.log`).
-   **Purpose**: Intermediate build artifacts, temporary data, logs.

### 4. File Storage (Potential)

-   **Module**: Potentially within feature modules or shared utility packages if direct file system storage is required. (*Requires human validation*)
-   **Purpose**: Storing files directly on device storage if needed.

## Key Files/Configuration

-   **`linka-android-kotlin/coreDatabase/`**: Contains Room database definitions and DAOs.
-   **`linka-android-kotlin/coreDatastore/`**: Contains DataStore setup and accessors.
-   **`linka-android-kotlin/tmp/` and `linka-android-kotlin/source/tmp/`**: Directories for temporary files.
-   **`AndroidManifest.xml`**: May declare storage permissions if direct file storage is used.

## Known Risks

-   Specific file paths and naming conventions for DAOs, Room Database classes, and DataStore accessors are inferential and require human validation.
-   The exact database schema and keys used in DataStore need human confirmation.
-   The precise lifecycle management and purpose of files within `tmp/` directories require validation.
