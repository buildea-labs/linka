# Data Flow

## Objective

This document details the data flow within the Linka Android Kotlin application, mapping components and interactions to actual module paths and inferred file locations.

## Flow Description

The application follows a unidirectional data flow pattern across modules:

1.  **User Interaction**: Triggered via Composables in `feature*/ui/` directories (e.g., `linka-android-kotlin/featureHome/src/main/kotlin/.../ui/HomeScreen.kt` - *necessita validação humana para nome exato*).
2.  **ViewModel Update**: UI events update state in ViewModels, typically located at `feature*/ui/*ViewModel.kt`.
    -   Example: `linka-android-kotlin/featureHome/src/main/kotlin/.../ui/HomeViewModel.kt` (*necessita validação humana*)
3.  **Data Request**: ViewModels request data from Repositories.
4.  **Repository Operations**: Repositories abstract data sources.
    -   **Network Data Source**: Utilizes interfaces likely defined in `linka-android-kotlin/coreNetwork/src/main/kotlin/.../api/ApiService.kt` (*necessita validação humana*). AI worker interaction uses `AiDiagnosisService.kt` (*inferential path, necessita validação humana*).
    -   **Database Data Source**: Interacts with DAOs in `linka-android-kotlin/coreDatabase/src/main/kotlin/.../dao/` (e.g., `DeviceDao.kt` - *necessita validação humana*).
    -   **DataStore**: Accesses preferences via classes in `linka-android-kotlin/coreDatastore/src/main/kotlin/.../` (e.g., `UserPreferencesDataSource.kt` - *inferential path, necessita validação humana*).
    -   **Repository Implementations**: Likely found in `core*/data/` or `feature*/data/` directories. Example: `linka-android-kotlin/coreNetwork/src/main/kotlin/.../data/DeviceRepository.kt` (*inferential path, necessita validação humana*).
5.  **Data Propagation**: Data flows from Data Sources -> Repository -> ViewModel -> UI State (`StateFlow`/`LiveData`) -> Composable UI.

## Component Interactions Mapped

-   **Entry Point**: `linka-android-kotlin/app/src/main/kotlin/com/linka/app/LinkaApp.kt` (*Standard entry point path, necessita validação humana para confirmação exata*).
-   **UI Layer**: Composables within `feature*/ui/` directories.
-   **State Management**: ViewModels within `feature*/ui/` directories.
-   **Data Access**: Repositories (in `core*/data/` or `feature*/data/`) and Data Sources (in `core*/api/`, `core*/dao/`, `core*/datasource/`).

## Asynchronous Operations

-   **Kotlin Coroutines**: Used extensively within ViewModels, Repositories, and Data Sources for non-blocking operations.

## Known Risks

-   Specific file paths and naming conventions for ViewModels, Repositories, Data Sources, DAOs, and Service interfaces are inferential and require human validation.
-   The exact implementation of state management (StateFlow vs. LiveData) and data transformation logic needs confirmation.
-   The interaction details with the `AiDiagnosisService` and its specific endpoints require human validation.
