# Build System

## Objective

This document details the build system and configurations for the Linka Android Kotlin project, mapping concrete file paths and roles.

## Primary Build Tool

-   **Gradle**: Used for build automation, invoked via `gradlew` and `gradlew.bat` scripts found at the project root: `linka-android-kotlin/gradlew` and `linka-android-kotlin/gradlew.bat`.

## Key Configuration Files and Roles

-   **`linka-android-kotlin/build.gradle.kts`**: Root project build script. Defines global configurations, repositories (e.g., Google, Maven Central), and plugin management.
-   **`linka-android-kotlin/settings.gradle.kts`**: Configures module inclusion. Lists all sub-modules (e.g., `app`, `coreDatabase`, `featureDevices`).
-   **`linka-android-kotlin/gradle.properties`**: Holds project-wide Gradle properties (version codes, build flags, JVM arguments).
-   **`linka-android-kotlin/app/build.gradle.kts`**: Main application module build script. Configures `applicationId`, `versionCode`, `versionName`, build types (`debug`, `release`), dependencies, and applies Android/Kotlin plugins.
-   **Module `build.gradle.kts` files**: Each module (e.g., `linka-android-kotlin/coreDatabase/build.gradle.kts`) declares its dependencies and plugin types (e.g., `com.android.library`).
-   **`linka-android-kotlin/key.properties` / `linka-android-kotlin/key.properties.template`**: Stores sensitive signing key information for release builds. Expected to be outside version control.
-   **`linka-android-kotlin/local.properties`**: Contains local environment settings, such as `sdk.dir` for the Android SDK path.

## Key Build Processes

-   **APK/App Bundle Generation**: Executed via Gradle tasks (e.g., `./gradlew assembleRelease` run from the project root).
-   **Dependency Management**: Gradle fetches dependencies from repositories defined in `build.gradle.kts`.
-   **Code Compilation**: Compiles Kotlin and Java source files within modules.
-   **Resource Processing**: Compiles Android resources.
-   **Testing**: Integrates with testing frameworks via Gradle tasks.

## Build Script Language

-   **Kotlin DSL (`.kts`)**: Gradle build scripts use Kotlin syntax.

## Known Risks

-   The precise Gradle tasks for specific build types and flavors require validation.
-   Security and correct management of `key.properties` require human oversight.
-   Exact dependency versions and configurations in `build.gradle.kts` files need thorough review.
