# API Map

## Objective

This document provides an overview of the Application Programming Interfaces (APIs) the Linka Android Kotlin application interacts with, categorizing them into internal module APIs and external service integrations.

## Internal Module APIs

The primary internal APIs for data access and services are exposed through interfaces defined within the core modules.

-   **`coreNetwork` Module**:
    -   **Description**: Defines interfaces for making network requests to backend services.
    -   **Key Interfaces**: `ApiService` (or similar naming convention) would define endpoints for RESTful communication.
    -   **Integration**: These interfaces are implemented and consumed by Repositories to fetch or send data to remote services.
    -   **Details**: Specific endpoints, request/response models, and serialization mechanisms are defined within this module.

-   **`coreDatabase` Module**:
    -   **Description**: Provides access to the local SQLite database via Data Access Objects (DAOs).
    -   **Key Interfaces**: DAO interfaces define CRUD (Create, Read, Update, Delete) operations for database tables.
    -   **Integration**: Repositories use DAOs to persist and retrieve local data.

-   **`coreDatastore` Module**:
    -   **Description**: Offers an API for accessing key-value storage.
    -   **Key Interfaces**: Provides methods for reading and writing preferences or settings.
    -   **Integration**: Used by ViewModels or Repositories to manage user preferences.

## External Service Integrations

The application integrates with various external services, some of which may be custom-built backend components.

-   **Backend Services (Inferred)**:
    -   **Description**: These are likely RESTful APIs exposed by a backend infrastructure, consumed via the `coreNetwork` module.
    -   **Potential Services**: Based on feature modules, these could include:
        -   Device registration and management APIs.
        -   Data synchronization services.
        -   User authentication services.
        -   APIs for fetching diagnostic data or status updates.
    -   **Authentication**: Details regarding authentication (e.g., OAuth, API keys) need human validation.

-   **Cloudflare AI Diagnosis Worker**:
    -   **Description**: A specific backend component for AI-driven diagnostics, deployed on Cloudflare.
    -   **Endpoint**: The mobile application likely communicates with this worker to send diagnostic data and receive AI-generated insights or suggestions.
    -   **Integration Point**: This would be an endpoint defined within `coreNetwork` and called by `featureDiagnostico` or related components.

-   **Speedtest Services**:
    -   **Description**: Integration with external or internal services for performing network speed tests.
    -   **Details**: This might involve connecting to specific speed test servers or APIs that facilitate these measurements. The exact providers or protocols require validation.

-   **Third-Party SDKs (Potential)**:
    -   **Description**: The application might incorporate third-party SDKs for specific functionalities (e.g., analytics, crash reporting). These would typically expose their own APIs.
    -   **Validation**: Need to check `build.gradle.kts` and `AndroidManifest.xml` for any such integrations.

## Key Files/Classes

-   `coreNetwork/src/main/kotlin/.../ApiService.kt` (and other API interface definitions)
-   `coreDatabase/src/main/kotlin/.../Dao.kt` (and other DAO definitions)
-   Repository implementations that consume these APIs.
-   `AndroidManifest.xml`: May list permissions required for network access.

## Documentation Standards

-   This map provides a high-level overview. Specific endpoint URLs, request/response structures, and authentication mechanisms are not detailed here.
-   All details regarding external API integrations require human validation.

## Known Risks

-   The exact list of external services, their endpoints, authentication methods, and data formats are not definitively known from the directory structure alone and require human validation.
-   The specific technologies used for backend services (e.g., REST, GraphQL) are inferred.
