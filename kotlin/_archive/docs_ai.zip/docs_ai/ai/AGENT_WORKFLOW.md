# Agent Workflow

## Objective

This document details the typical workflow for AI agents interacting with the Linka Android Kotlin project, mapping roles, skills, and workflow stages to concrete files and configurations.

## Agent Roles and Mappings

Inferred agent roles and their potential locations:

-   **`CAIO_ENGINEER`**: Primary implementation agent. Role definition likely in `.orbit/agents/CAIO_ENGINEER.md` (*necessita validação humana para path exato*).
-   **`CLAUDIO_TECH_LEAD`**: Technical oversight and architecture. Role definition likely in `.orbit/agents/CLAUDIO_TECH_LEAD.md` (*necessita validação humana para path exato*).
-   **`LIA_UX_LEAD`**: UX and design consistency. Role definition likely in `.orbit/agents/LIA_UX_LEAD.md` (*necessita validação humana para path exato*).

## Workflow Stages with Mapped Components

1.  **Task Understanding**: Tasks are received, context gathered from `docs_ai/README.md`, `technical/ARCHITECTURE.md`, and relevant feature documentation.
2.  **Research & Investigation**: Utilizes tools like `grep_search` on codebase files (e.g., `feature*/ui/*.kt`, `core*/src/main/kotlin/**/*.kt`), `read_file` on specific docs (e.g., `technical/BUILD_SYSTEM.md`), and `list_directory` on module paths.
3.  **Planning**: May use `enter_plan_mode`. Plans reference `ai/TASK_BREAKDOWN.md`.
4.  **Implementation**: Uses `write_file` on markdown files in `docs_ai/`, `replace` on code files, `run_shell_command` for build tasks (referencing `technical/BUILD_SYSTEM.md`).
5.  **Verification**: Runs build commands (`./gradlew` from root), linting (`./gradlew lint`), and tests (tasks defined in module `build.gradle.kts`).
6.  **Reporting & Handoff**: Uses `paperclip` skill (configuration likely in `.orbit/skills/ENGINEERING_EXECUTION.md`) and follows rules in `ai/HANDOFF_RULES.md`.

## Tool Usage

-   **File Ops**: `read_file`, `write_file`, `replace`.
-   **Codebase Exploration**: `grep_search`, `glob`, `list_directory`.
-   **Command Execution**: `run_shell_command` (e.g., `./gradlew build`).
-   **Agent Delegation**: `invoke_agent`.
-   **Skill Activation**: `activate_skill` (e.g., `ENGINEERING_EXECUTION`, `MD3_REVIEW`).
-   **User Interaction**: `ask_user`.

## Key Files/Configuration

-   **Agent Definitions**: `.orbit/agents/` (e.g., `CAIO_ENGINEER.md`).
-   **Skill Definitions**: `.orbit/skills/` (e.g., `ENGINEERING_EXECUTION.md`, `MD3_REVIEW.md`).
-   **Workflow Policies**: `.orbit/workflow/` (e.g., `CONTEXT_POLICY.md`).
-   **AI Documentation**: `docs_ai/ai/` for workflow rules.

## Known Risks

-   Exact agent role definitions and file paths in `.orbit/agents/` require human validation.
-   The specific implementation details of skills like `ENGINEERING_EXECUTION` need confirmation.
-   The effectiveness of automated verification steps depends on the project's test suite configuration.
