# Handoff Rules

## Objective

This document details the rules and protocols for task handoffs between AI agents, mapping them to specific files and skills within the Linka Android Kotlin project.

## Handoff Scenarios and Mappings

Handoffs occur based on task complexity and agent specialization:

-   **Task Complexity / Specialization**: Handoffs are triggered when a task requires different expertise.
    -   Example: `CAIO_ENGINEER` might hand off architectural review to `CLAUDIO_TECH_LEAD`, or UI design specs to `LIA_UX_LEAD`.
    -   Example: `CLAUDIO_TECH_LEAD` might hand off detailed implementation to `CAIO_ENGINEER`.
-   **Sequential Dependencies**: Agents follow defined sequences, handing off upon task completion. This is guided by workflow definitions in `.orbit/workflow/`.

## Handoff Protocol and Tools

-   **Information Transfer**: Contextual summaries, deliverables, and task state are communicated.
-   **Activation/Notification**: Uses `invoke_agent` or task assignment systems.
    -   **`paperclip` Skill**: Potentially used for task coordination. Refer to `.orbit/skills/COMPACT_HANDOFF.md` for specific integration details.
-   **Scope Definition**: Handoffs clearly define the receiving agent's responsibilities.

## Agent Specialization and Handoff Examples

-   **`CAIO_ENGINEER`** -> **`CLAUDIO_TECH_LEAD`**: Hand off complex architectural decisions or review findings.
-   **`CLAUDIO_TECH_LEAD`** -> **`CAIO_ENGINEER`**: Hand off implementation tasks after architectural guidance.
-   **`LIA_UX_LEAD`** -> **`CAIO_ENGINEER`**: Hand off UI specifications for coding.

## Key Files/Configuration

-   **`.orbit/skills/COMPACT_HANDOFF.md`**: Specific guidance on compact handoff execution.
-   **`.orbit/agents/`**: Role definitions (e.g., `CAIO_ENGINEER.md`, `CLAUDIO_TECH_LEAD.md`, `LIA_UX_LEAD.md`) indicating specialization.
-   **`.orbit/workflow/`**: Workflow definitions may outline handoff sequences.
-   **`ai/TASK_BREAKDOWN.md`**: Details task decomposition, implying handoff points.

## Known Risks

-   Specific handoff mechanism implementations require human validation.
-   Clarity of task boundaries and communication protocols between agents is critical and needs human review.
-   The coordination logic and effectiveness of the `paperclip` skill need validation.
