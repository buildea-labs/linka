# Task Breakdown

## Objective

This document details the principles and process for task breakdown, mapping them to specific files, agent roles, and skills within the Linka Android Kotlin project.

## Task Decomposition Principles and Mappings

Complex tasks are broken down based on project structure and agent specialization:

-   **Modularity**: Decomposition aligns with project modules (`app`, `core*`, `feature*`). Example: A task to implement a new feature would involve `feature<NewFeature>/`.
-   **Separation of Concerns**: Sub-tasks focus on single responsibilities. Example: Modifying `featureSettings/ui/SettingsScreen.kt` for a specific setting.
-   **Granularity**: Tasks are defined for actionable units, typically a single verifiable change or investigation.
-   **Dependency Identification**: Dependencies tracked, potentially referencing `ai/TASK_BREAKDOWN.md` itself for process definition.

## Process for AI Agents and Mapped Components

1.  **Task Analysis**: Agents receive tasks. Context gathered from `docs_ai/README.md`, `technical/ARCHITECTURE.md`.
2.  **Decomposition**: Tasks broken down using:
    -   **`ISSUE_DECOMPOSITION` Skill**: Configuration/guidance likely in `.orbit/skills/ISSUE_DECOMPOSITION.md`.
    -   **Agent Roles**: `CLAUDIO_TECH_LEAD` may oversee decomposition for technical tasks; `LIA_UX_LEAD` for UX-related ones. Agent role definitions are in `.orbit/agents/`.
3.  **Role Assignment**: Sub-tasks assigned based on agent specialization (e.g., `CAIO_ENGINEER` for coding).
4.  **Dependency Mapping**: Implicit in task sequences defined by workflow rules (`.orbit/workflow/`).
5.  **Deliverable Definition**: Achieved via task completion within the agent's workflow (`ai/AGENT_WORKFLOW.md`).

## Key Files/Configuration

-   **`.orbit/skills/ISSUE_DECOMPOSITION.md`**: Guidance for the decomposition skill.
-   **`.orbit/agents/`**: Role definitions (e.g., `CLAUDIO_TECH_LEAD.md`, `LIA_UX_LEAD.md`, `CAIO_ENGINEER.md`).
-   **`ai/TASK_BREAKDOWN.md`**: This document itself, defining the process.
-   **`ai/AGENT_WORKFLOW.md`**: General workflow context.

## Known Risks

-   Specific decomposition criteria and dependency management logic require human validation.
-   Accurate agent assignment depends on well-defined agent capabilities in `.orbit/agents/`.
-   The practical effectiveness of the `ISSUE_DECOMPOSITION` skill needs confirmation.
