# Review Flow for Agents

## Objective

This document details the review process for code, documentation, and design artifacts, mapping review types, criteria, and AI agent participation to specific project files and skills.

## Review Types and Criteria

Reviews ensure quality and adherence to standards:

-   **Code Reviews**: Evaluate changes in `linka-android-kotlin/` modules. Criteria include correctness, style (`technical/BUILD_SYSTEM.md`), architecture (`technical/ARCHITECTURE.md`), performance, security, and testing.
-   **Documentation Reviews**: Assess docs in `docs_ai/` and `docs/` for accuracy, clarity, AI-friendliness, and conciseness.
-   **UX/Design Reviews**: Evaluate UI/UX against `design-system/` guidelines and user-centric principles. Criteria include MD3 adherence (`design-system/MD3_GUIDELINES.md`), component usage (`design-system/COMPONENTS.md`), and flows (`functional/` docs).

## Review Process and Agent Participation

1.  **Initiation**: Triggered by agent task completion (code commit, doc update).
2.  **Automated Checks**: Agents run linters, formatters (via `./gradlew` tasks), and basic tests.
3.  **Specialized Reviews**:
    -   **Technical**: `CLAUDIO_TECH_LEAD` reviews code/architecture. Role in `.orbit/agents/CLAUDIO_TECH_LEAD.md`.
    -   **UX/Design**: `LIA_UX_LEAD` reviews UI/UX. Role in `.orbit/agents/LIA_UX_LEAD.md`. Uses `MD3_REVIEW` skill (`.orbit/skills/MD3_REVIEW.md`) for design system checks.
    -   **Code Implementation**: `CAIO_ENGINEER` may perform self-reviews or initial checks. Role in `.orbit/agents/CAIO_ENGINEER.md`.
4.  **Feedback**: Agents provide feedback. Human oversight is crucial for final approval.

## Key Files/Configuration

-   **`.orbit/skills/MD3_REVIEW.md`**: Guidance for MD3 compliance checks.
-   **`.orbit/agents/`**: Role definitions (e.g., `CLAUDIO_TECH_LEAD.md`, `LIA_UX_LEAD.md`).
-   **Documentation**: `docs_ai/` and `docs/` contain review criteria.
-   **Code/Docs**: Files in `linka-android-kotlin/`, `docs_ai/` are subjects of review.

## Known Risks

-   Specific review checklists and human oversight for final sign-off require validation.
-   AI agents may not catch all subjective issues; human judgment is essential.
-   Feedback incorporation process needs clear definition.
