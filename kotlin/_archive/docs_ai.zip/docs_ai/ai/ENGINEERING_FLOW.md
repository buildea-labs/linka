# Engineering Flow for Agents

## Objective

This document details the engineering workflow for AI agents, mapping their contributions to specific project modules, skills, and tools.

## Engineering Goals and AI Contributions

AI agents adhere to software engineering best practices:

-   **Code Quality**: Agents contribute to high-quality code within `linka-android-kotlin/` modules (e.g., `feature*/`, `core*/`).
-   **Convention Adherence**: Follows patterns described in `technical/` docs (e.g., `ARCHITECTURE.md`, `DATA_FLOW.md`).
-   **Efficiency & Reliability**: Agents write performant code and tests.
-   **Documentation**: Generate/update docs in `docs_ai/` and `docs/`.
-   **Build System**: Assist with `technical/BUILD_SYSTEM.md` configurations via Gradle tasks (`run_shell_command "./gradlew ..."`).

## Workflow Steps (Engineering Focus)

1.  **Task Intake**: Engineering tasks (e.g., "Implement X feature," "Fix bug Y") are received.
2.  **Codebase Analysis**: Agents analyze relevant code in `linka-android-kotlin/` modules using `grep_search`, `read_file`. Context from `technical/` docs is used.
3.  **Planning**: Plan implementation using `enter_plan_mode`, referencing `ai/TASK_BREAKDOWN.md`.
4.  **Implementation**: Write/modify code using `write_file`, `replace` in feature/core modules.
5.  **Testing**: Write/update tests in `feature*/src/androidTest/` or `feature*/src/test/` (*inferential paths*).
6.  **Build & Verification**: Execute `./gradlew build`, `./gradlew lint`, `./gradlew test` via `run_shell_command`.
7.  **Documentation Update**: Update `docs_ai/` and `technical/` docs.

## Specialized Skills and Agents

-   **`ENGINEERING_EXECUTION` Skill**: Configured/detailed in `.orbit/skills/ENGINEERING_EXECUTION.md`. Provides capability for build tasks and verification.
-   **`CAIO_ENGINEER`**: Primary agent for coding, fixing, and testing tasks. Role defined in `.orbit/agents/CAIO_ENGINEER.md`.
-   **`CLAUDIO_TECH_LEAD`**: Oversees architectural compliance and reviews technical implementations. Role in `.orbit/agents/CLAUDIO_TECH_LEAD.md`.

## Key Files/Configuration

-   **`.orbit/skills/ENGINEERING_EXECUTION.md`**: Details engineering execution capabilities.
-   **`.orbit/agents/CAIO_ENGINEER.md`**: Role definition.
-   **`technical/` Documentation**: Provides context on architecture, build system, services.
-   **Build Scripts**: `gradlew`, `*.gradle.kts` files.

## Known Risks

-   Specific engineering practices and standards enforced by skills require human validation.
-   CI/CD integration details are not covered here and need human confirmation.
-   Ensuring agents don't introduce regressions requires robust testing verification.
