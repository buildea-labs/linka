# UX Flow for Agents

## Objective

This document details the user experience (UX) flow from an AI agent's perspective, mapping UX goals, agent contributions, and design system adherence to specific project files.

## UX Goals and AI Contributions

AI agents uphold core UX principles:

-   **Intuitiveness & Efficiency**: Ensured by following design patterns documented in `design-system/` files (e.g., `NAVIGATION.md`, `COMPONENTS.md`).
-   **Consistency**: Maintained through adherence to MD3 guidelines and usage of components from `design-system/` docs.
-   **Accessibility**: Addressed via contrast checks (referenced in `design-system/COLORS.md`) and standard component usage.
-   **User Delight**: Achieved through meaningful motion (`design-system/MOTION.md`) and clear AI output presentation (`functional/AI_ASSISTANT.md`).

## UX Design Principles and Workflow

Agents, especially `LIA_UX_LEAD`, follow these principles:

1.  **User-Centricity**: Design decisions prioritize user needs, analyzed through functional flows (`functional/` docs).
2.  **MD3 Adherence**: Strict use of guidelines from `design-system/` docs. `MD3_REVIEW` skill (config in `.orbit/skills/MD3_REVIEW.md`) aids validation.
3.  **Accessibility**: Cross-referenced with `design-system/COLORS.md`, `design-system/TYPOGRAPHY.md`.
4.  **Iterative Design**: UX improvements informed by analysis of functional flows and potential user feedback analysis.
5.  **Consistency Check**: New UI elements align with `design-system/COMPONENTS.md` and `design-system/NAVIGATION.md`.

## Agent Contributions

-   **`LIA_UX_LEAD`**: Reviews UI implementations, ensuring adherence to `design-system/` guidelines and user-centricity. Role in `.orbit/agents/LIA_UX_LEAD.md`.
-   **`CAIO_ENGINEER`**: Implements UI according to UX specs and design guidelines found in `design-system/` docs.
-   **`CLAUDIO_TECH_LEAD`**: Assesses technical feasibility of UX designs.

## Key Files/Configuration

-   **`.orbit/skills/MD3_REVIEW.md`**: For checking MD3 compliance.
-   **`.orbit/agents/LIA_UX_LEAD.md`**: Role definition for UX agent.
-   **`design-system/`**: Contains detailed guidelines (COMPONENTS, COLORS, TYPOGRAPHY, SPACING, MOTION, CHAT_PATTERNS, NAVIGATION).
-   **`functional/`**: Describes user flows (e.g., `AI_ASSISTANT.md`, `DIAGNOSTIC_FLOW.md`).

## Known Risks

-   Specific UX interpretations and detailed accessibility validation require human oversight.
-   Translating abstract UX goals into concrete UI requires human judgment.
