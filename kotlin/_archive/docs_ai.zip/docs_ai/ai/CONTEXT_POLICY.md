# Context Policy

## Objective

This document details the context policy for AI agents, mapping context management strategies to specific tools and documentation files within the Linka Android Kotlin project.

## Context Management and Sources

AI agents utilize context from various sources:

-   **Codebase**: Explored via `grep_search` and `read_file` on files within `linka-android-kotlin/` and its modules (e.g., `feature*/ui/*.kt`, `core*/src/main/kotlin/**/*.kt`).
-   **Documentation**:
    -   **AI-Generated**: `docs_ai/` (e.g., `technical/ARCHITECTURE.md`, `design-system/COLORS.md`) is prioritized as structured, concise context.
    -   **Project Docs**: `docs/` for broader project information.
-   **Project Structure**: Inferred from `list_directory` and module paths (e.g., `featureDevices/`, `coreNetwork/`).
-   **Agent Configurations**: `.orbit/agents/` and `.orbit/skills/` define agent capabilities and workflow rules.
-   **Session History**: Transient session state is not retained; durable memory is persisted.

## Context Compression and Prioritization Strategies

-   **Relevance Filtering**: `grep_search` on specific files/modules, targeted `read_file` calls based on task relevance.
-   **Prioritization**: `docs_ai/` takes precedence. Core architectural files (`ARCHITECTURE.md`, `MODULES.md`) and AI-generated docs are prioritized.
-   **Efficiency**: Minimal tool usage, avoiding redundant queries.
-   **Summarization**: Long documents may be summarized if loaded.

## Policy for AI Agents

1.  **Prioritize `docs_ai/`**: Use AI-generated documentation as the primary, structured context.
2.  **Task-Specific Context**: Load only information directly relevant to the current task.
3.  **Minimize Token Usage**: Employ efficient search and read operations.
4.  **Respect `needs human validation`**: Do not make definitive assumptions where human confirmation is required.
5.  **Leverage Tooling**: Use `grep_search` and targeted file reads over broad scans.

## Key Files/Configuration

-   **`docs_ai/README.md`**: Primary index, mapping all documentation.
-   **`docs_ai/technical/`**: Core technical context.
-   **`.orbit/workflow/CONTEXT_POLICY.md`**: Specific workflow rules for context management (*explicitly mentioned in prompt*).
-   **Agent Configurations**: `.orbit/agents/` and `.orbit/skills/` provide context on agent capabilities.

## Known Risks

-   Exact context filtering logic and compression algorithms require human validation.
-   Risk of missing critical context if filtering is too aggressive.
