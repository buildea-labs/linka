# Chat Patterns

## Objective

This document inventories UI patterns for chat-like or conversational interactions, mapping them to concrete components and locations, especially for AI features.

## AI Integration Patterns and Mappings

AI features, particularly AI diagnostics, may use conversational UI elements.

-   **AI Response Presentation**:
    -   **Message Bubbles/Cards**: AI insights are likely presented using `Card` or `Surface` composables, potentially styled distinctively.
    -   **Location**: Primarily within `linka-android-kotlin/featureDiagnostico/ui/DiagnosticScreen.kt` (*inferential path*). May also appear in `featureHome/ui/HomeScreen.kt` (*inferential path*).
    -   **Avatar/Iconography**: A distinct icon for AI is used, likely managed within a shared `coreui/` module or directly in feature UI. (*Needs validation for specific implementation*)

-   **AI State Indication**:
    -   **Thinking/Processing Animation**: Visual cues (e.g., loading indicators) are used during AI processing.
    -   **Implementation**: Likely employs `CircularProgressIndicator` or custom animations within `featureDiagnostico/ui/DiagnosticScreen.kt`.

-   **User Interaction with AI Output**:
    -   **Action Buttons**: Buttons (standard MD3 `Button` composables) are used for interactive AI suggestions. These are part of the UI in `featureDiagnostico/ui/`.
    -   **Follow-up Prompts**: If implemented, would be custom UI elements within `featureDiagnostico/ui/`. (*Needs validation*)

## Key Files/Modules

-   **`linka-android-kotlin/featureDiagnostico/ui/`**: Contains `DiagnosticScreen.kt` and `DiagnosticViewModel.kt` where AI results are displayed and interaction logic resides (*inferential paths*).
-   **`linka-android-kotlin/coreNetwork/ai/AiDiagnosisService.kt`**: Handles communication with the AI backend.
-   **`linka-android-kotlin/app/ui/` or `coreui/`**: May contain shared UI components for message presentation or avatars. (*Needs validation*)

## Known Risks

-   Specific implementation details of AI conversational UI elements require human validation.
-   The exact nature of AI interaction (insights vs. dialogue) needs confirmation.
-   The visual distinction and tone of AI messages compared to app content require review.
