# Spacing Guidelines

## Objective

This document details the spacing guidelines for the Linka Android Kotlin application, mapping spacing values to their implementation locations.

## Material Design 3 Spacing Principles and Application

The application follows MD3's recommendation for a systematic approach to spacing, often using an 8dp grid.

-   **8dp Grid System**: Spacing units are derived from multiples of 8dp.
    -   **Common Values**: 4dp, 8dp, 12dp, 16dp, 24dp, 32dp+.
    -   **Application**: Applied via `Modifier.padding()` and `Modifier.height()`, `Modifier.width()` in Jetpack Compose UI files within `feature*/ui/` directories.

-   **Consistent Margins/Paddings**: Spacing defines separation between UI elements and containers.
-   **Vertical Rhythm**: Applied to text and controls for readability.

## Defined Spacing Units and Usage

-   **4dp**: Fine adjustments, small gaps.
-   **8dp**: Fundamental unit for padding/margins (e.g., in `Card` components, list items).
-   **16dp**: Standard padding for screens and major sections.
-   **24dp+**: For significant divisions between content areas.

*(Exact values and their application should be validated in the codebase.)*

## Key Files/Configuration

-   **Compose UI Files**: Spacing values are directly applied using `Modifier.padding(dp)` in composables across `feature*/ui/` directories.
-   **Theme Definition**: Potentially, default spacing constants might be defined in `linka-android-kotlin/app/src/main/kotlin/com/linka/ui/theme/Theme.kt` (*inferential path*).
-   **Dimension Resources**: Less common in Compose, but `res/values/dimens.xml` could hold some values. (*Requires human validation*)

## Known Risks

-   The precise set of spacing values used and their consistent application across all components need human validation.
-   Custom spacing modifiers or specific component-level overrides require review.
