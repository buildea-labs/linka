# Typography

## Objective

This document details the typography guidelines for the Linka Android Kotlin application, mapping styles to their implementation and referencing specific files.

## Material Design 3 Typography Scale and Application

The application uses Jetpack Compose's Material 3 typography system. Styles are applied via `MaterialTheme.typography`.

-   **MD3 Styles**: The standard MD3 scale (Display, Headline, Title, Body, Label) is used.
    -   **Usage**: Applied within UI composables in `feature*/ui/` directories. Specific usage for each style needs validation per screen.
-   **Font Family**:
    -   **Primary Font**: `Roboto` is inferred as the primary font. Font files, if bundled, would likely be in `linka-android-kotlin/app/src/main/res/font/` (*necessita validação humana para path exato*).
    -   **Fallback**: Standard system fonts.

## Font Weights and Styles

-   **Weights**: Regular (400), Medium (500), Semi-bold (600) are used. Applied via `fontWeight` parameter in `Text` composables.
-   **Styles**: Standard text styles are used as needed.

## Application-Specific Styles

-   Customizations or additions to the MD3 scale, if any, would be defined in the theme file:
    -   **Theme Definition**: Likely located at `linka-android-kotlin/app/src/main/kotlin/com/linka/ui/theme/Theme.kt` (*inferential path*).
    -   **Custom Styles**: Any unique styles for AI text or specific UI elements need validation.

## Key Files/Configuration

-   **`linka-android-kotlin/app/src/main/kotlin/com/linka/ui/theme/Theme.kt`**: Defines `MaterialTheme` and typography styles (*inferential path*).
-   **`linka-android-kotlin/app/build.gradle.kts`**: May include font family declarations or dependencies.
-   Composable UI files in `feature*/ui/` packages: Where `Text` composables utilize `MaterialTheme.typography`.

## Known Risks

-   Exact font file names and locations require human validation.
-   The precise mapping of MD3 styles to specific UI elements needs confirmation.
-   Any custom typography variations require validation.
