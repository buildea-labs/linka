# Motion and Animations

## Objective

This document details the application of motion and animations within the Linka Android Kotlin application, mapping specific implementations and types of motion.

## Material Design 3 Motion Principles Applied

Motion is used purposefully for:
-   **Feedback**: Visual cues for user actions (e.g., button presses).
-   **Guidance**: Directing user attention during transitions or state changes.
-   **Status Indication**: Animating progress indicators.

## Motion Implementations and Mappings

-   **Screen Transitions**: Managed by Jetpack Navigation Component for Compose, likely configured in `linka-android-kotlin/app/ui/AppNavigation.kt` (*inferential path*).
-   **Micro-interactions**: Implemented using Compose animation APIs (`animate*AsState`, `animateContentSize`) within specific UI composables in `feature*/ui/` directories (e.g., toggling states in `featureSettings/ui/SettingsScreen.kt` - *inferential path*).
-   **Loading/Progress Indicators**:
    -   `CircularProgressIndicator`, `LinearProgressIndicator` composables used in `feature*/ui/` screens during data fetching or AI processing (e.g., `featureSpeedtest/ui/SpeedtestScreen.kt`, `featureDiagnostico/ui/DiagnosticScreen.kt` - *inferential paths*).
-   **AI State Animations**:
    -   **Thinking/Processing**: Visual cues (e.g., pulsing animations, spinners) likely implemented in `featureDiagnostico/ui/DiagnosticScreen.kt` when interacting with `AiDiagnosisService.kt` (*inferential paths*).
    -   **Response Delivery**: Subtle animations for displaying AI insights, possibly using `AnimatedVisibility` or state-based animations in `featureDiagnostico/ui/`.

## Implementation Details

-   **Jetpack Compose Animation APIs**: `animate*AsState`, `transition`, `AnimatedVisibility`, `animateContentSize`.
-   **Custom Animations**: May exist for specific UI elements, likely within shared `coreui/` or directly in feature UI packages. (*Requires human validation*)

## Key Files/Configuration

-   Composable UI files in `feature*/ui/` directories: Where animations are directly implemented.
-   `linka-android-kotlin/app/ui/AppNavigation.kt`: For screen transition animations (*inferential path*).
-   `linka-android-kotlin/coreui/` (potential): For shared animation utilities.

## Known Risks

-   Specific animation triggers, timings, easing curves, and custom animations need human validation.
-   Ensuring animations respect system reduced motion settings requires verification.
