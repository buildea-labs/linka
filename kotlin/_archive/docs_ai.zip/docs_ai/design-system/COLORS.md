# Color System

## Objective

This document details the color system of the Linka Android Kotlin application, mapping color roles to their implementation and referencing specific files.

## Material Design 3 Color System Implementation

The application's color system is based on MD3 principles:

-   **Dynamic Color**: Supported via Jetpack Compose Material 3 theming. Color extraction and application logic are likely handled in the theme definition.
-   **Color Roles**: Defined and applied systematically.
    -   **Primary, Secondary, Tertiary**: Used for interactive elements and key UI. Applied via `MaterialTheme.colorScheme.primary`, `secondary`, `tertiary` in composables.
    -   **Error**: Used for input errors and alerts, accessed via `MaterialTheme.colorScheme.error`.
    -   **Surface, Background**: Define component and screen backgrounds, accessed via `MaterialTheme.colorScheme.surface`, `background`.
    -   **Variants**: Used for states or accents, accessed via `primaryVariant`, `secondaryVariant`, etc. (*Note: `*Variant` properties are deprecated in M3; consider `primary` with alpha or specific tonal palettes. Needs validation.*)
-   **Contrast and Accessibility**: Ensured by adhering to MD3 contrast guidelines and potentially validated via tooling or manual checks.

## Color Palettes and Mappings

-   **Default/Static Palette**:
    -   **Implementation**: Defined in `linka-android-kotlin/app/src/main/kotlin/com/linka/ui/theme/Color.kt` (*inferential path*). Contains static color definitions for Primary, Secondary, Tertiary, Error, Surface, Background, and their variants.
    -   **Branding Colors**: Specific brand colors are likely integrated into this static palette. Refer to `docs/branding/` for details (*if such files exist and contain color info*).

-   **Dynamic Color Palette**:
    -   **Implementation**: Enabled in the theme definition file (`Theme.kt`), leveraging Android's dynamic color APIs.
    -   **Fallback**: If dynamic color is unavailable or disabled, the static palette from `Color.kt` is used.

## Key Files/Configuration

-   **`linka-android-kotlin/app/src/main/kotlin/com/linka/ui/theme/Color.kt`**: Defines the static color tokens and palettes (*inferential path*).
-   **`linka-android-kotlin/app/src/main/kotlin/com/linka/ui/theme/Theme.kt`**: Implements the `MaterialTheme` composable, incorporating color schemes (static and dynamic). (*inferential path*)
-   Composable UI files in `feature*/ui/` packages: Where `MaterialTheme.colorScheme` properties are consumed.
-   `docs/branding/`: Potential source for brand color definitions.

## Known Risks

-   Exact file paths for theme and color definitions require human validation.
-   The specific implementation and fallback logic for dynamic color need confirmation.
-   Ensuring sufficient contrast across all color roles and UI states requires human review and testing.
-   Deprecation of `*Variant` color roles in M3 might indicate an older implementation requiring updates.
