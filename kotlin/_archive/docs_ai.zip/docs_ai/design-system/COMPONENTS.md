# Component Registry

## Objective

This document inventories the reusable UI components within the Linka Android Kotlin application, mapping them to their likely module locations and types.

## Component Library Mappings

The application uses Jetpack Compose Material 3 components and custom ones:

### 1. Layout Components

-   **`Scaffold`**: Used within `feature*/ui/` screens for app structure.
-   **`Column`, `Row`, `Box`**: Widely used across all `feature*/ui/` packages for layout composition.
-   **`Surface`**: Used for background elements and theming, often in shared UI modules or directly in feature screens.

### 2. Navigation Components

-   **`TopAppBar`**: Found in `app/ui/` or `feature*/ui/` for screen titles and actions.
-   **`BottomAppBar` / `NavigationBar`**: Likely defined in `app/ui/` or `coreui/` for primary app navigation.
-   **`NavigationDrawer`**: Potentially in `app/ui/` or `coreui/` for secondary navigation.
-   **`Tabs`**: Used within specific feature screens (e.g., `featureSettings/ui/SettingsScreen.kt` - *inferential path*).

### 3. Input Controls

-   **`TextField` / `OutlinedTextField`**: Used in forms across features like `featureSettings/`, `featureDevices/`.
-   **`Checkbox`, `RadioButton`, `Switch`, `Slider`**: Used in `featureSettings/ui/` and other feature settings UIs.
-   **`Button`**: Standard action buttons used across all `feature*/ui/` packages.
-   **`FloatingActionButton` (FAB)**: Potentially in `featureHome/ui/` or other primary feature screens.

### 4. Display Components

-   **`Card`**: Used for grouping information, e.g., in `featureHome/ui/` for status summaries, or `featureHistory/ui/` for log entries.
-   **`List` / `ListItem`**: Ubiquitous, used in `featureDevices/ui/`, `featureHistory/ui/`, `featureSettings/ui/` for displaying lists of items.
-   **`AlertDialog`, `Dialog`**: Used across features for confirmations or detailed info, often within `feature*/ui/` screens.
-   **`Snackbar`**: Used for feedback messages, managed via ViewModels and displayed in top-level screens (`app/ui/` or `featureHome/ui/`).
-   **`Chip`**: Used in `featureSettings/ui/` or for filtering/tagging information.
-   **`Avatar` / `Image`**: Used in `featureHome/ui/` (user status) or `featureDevices/ui/` (device icons).
-   **`Icon`**: Used extensively across all UI modules.

### 5. Progress Indicators

-   **`CircularProgressIndicator`, `LinearProgressIndicator`**: Used in various `feature*/ui/` screens during data loading or AI processing (e.g., `featureSpeedtest/ui/`, `featureDiagnostico/ui/`).

### 6. AI-Specific UI Components (Inferred)

-   **AI Insight Cards/Banners**: Likely custom or themed `Card` or `Surface` composables within `featureDiagnostico/ui/DiagnosticScreen.kt` or `featureHome/ui/HomeScreen.kt`. (*Needs validation for specific implementation*)
-   **Chat-like Elements**: If used, these would be custom composables within `featureDiagnostico/ui/` or potentially a shared `coreui/chat/` package. (*Needs validation*)

### 7. Custom Components

-   **Location**: Potentially in a shared `coreui/` module or within specific `feature*/ui/` packages if highly localized. (*Requires human validation*)

## Usage Guidelines

-   Standard MD3 components should be preferred. Custom components should aim for MD3 compatibility.
-   Refer to `design-system/COLORS.md`, `design-system/TYPOGRAPHY.md`, `design-system/SPACING.md`, `design-system/MOTION.md` for consistent styling.

## Known Risks

-   The complete inventory of custom components and their exact locations require human validation.
-   Specific styling and behavior of components, especially AI-related ones, need confirmation.
