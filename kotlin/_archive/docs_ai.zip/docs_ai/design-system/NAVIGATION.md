# Navigation Patterns

## Objective

This document details the navigation patterns within the Linka Android Kotlin application, mapping components to their likely implementation locations.

## Navigation Patterns and Mappings

The application employs standard navigation patterns for user movement:

### 1. App-Level Navigation

-   **`BottomAppBar` / `NavigationBar`**:
    -   **Usage**: Likely implemented in `linka-android-kotlin/app/ui/AppNavigation.kt` or `coreui/` for top-level destinations (`featureHome`, `featureDiagnostico`, `featureSettings`, etc. - *inferential paths*).
-   **`NavigationDrawer`**:
    -   **Usage**: Potentially implemented in `app/ui/` or `coreui/` for secondary navigation. (*Requires human validation*)
-   **`TopAppBar`**:
    -   **Usage**: Present across most screens in `feature*/ui/` directories for titles and actions.

### 2. In-Screen Navigation

-   **`Tabs`**:
    -   **Usage**: Could be used within specific screens like `featureSettings/ui/SettingsScreen.kt` or `featureDevices/ui/DeviceScreen.kt` (*inferential paths*).
-   **Internal Links/Buttons**: Implemented via standard `Button` or `TextButton` composables within various `feature*/ui/` screens.

### 3. Jetpack Navigation Component (Compose)

-   **Implementation**: Navigation graph and `NavController` likely managed in:
    -   `linka-android-kotlin/app/ui/AppNavigation.kt` (*inferential path*) for the main graph.
    -   Feature modules (`feature*/ui/`) may define their own sub-navigation.
-   **`NavController`**: Used programmatically within ViewModels or UI layers for navigation actions.

## Key Files/Modules

-   **`linka-android-kotlin/app/ui/`**: Likely contains `AppNavigation.kt` and `Theme.kt` (*inferential paths*) for primary navigation setup.
-   **`feature*/ui/`**: Screens defined here integrate with the `NavController`.
-   **`coreui/` (potential)**: May contain reusable navigation components or structures.

## Known Risks

-   The exact structure of the navigation graph and specific destination routes require human validation.
-   The precise implementation of navigation animations and deep linking needs confirmation.
