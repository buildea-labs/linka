# Linka Android Kotlin Project AI Documentation

This repository contains AI-friendly documentation for the Linka Android Kotlin project, designed to facilitate efficient understanding, development, and maintenance by AI agents.

## Structure

The documentation is organized into the following top-level categories:

-   **Technical Documentation (`technical/`)**: Details the project's architecture, modules, data flow, APIs, AI integration, and build systems.
-   **Functional Documentation (`functional/`)**: Describes the application's features, user flows, and expected behaviors.
-   **Design System (`design-system/`)**: Outlines the visual guidelines, components, typography, spacing, and UX patterns, including Material Design 3 and chat-specific elements.
-   **Wireframes (`wireframes/`)**: Contains visual representations and flows of UI elements and user journeys.
-   **Operations Documentation (`operations/`)**: Covers release processes, versioning, APK building, environment management, and deployment.
-   **AI Documentation (`ai/`)**: Documents workflows, context policies, handoff rules, and task breakdown specific to AI agents interacting with the project.

## Navigation

Use the links below to navigate through the documentation:

### Technical
-   [Architecture Overview (`technical/ARCHITECTURE.md`)](./technical/ARCHITECTURE.md)
-   [Module Breakdown (`technical/MODULES.md`)](./technical/MODULES.md)
-   [Data Flow (`technical/DATA_FLOW.md`)](./technical/DATA_FLOW.md)
-   [API Map (`technical/API_MAP.md`)](./technical/API_MAP.md)
-   [AI Flow (`technical/AI_FLOW.md`)](./technical/AI_FLOW.md)
-   [Cloudflare Integration (`technical/CLOUDFLARE.md`)](./technical/CLOUDFLARE.md)
-   [Storage Details (`technical/STORAGE.md`)](./technical/STORAGE.md)
-   [Services Overview (`technical/SERVICES.md`)](./technical/SERVICES.md)
-   [Build System (`technical/BUILD_SYSTEM.md`)](./technical/BUILD_SYSTEM.md)

### Functional
-   [Core Features (`functional/FEATURES.md`)](./functional/FEATURES.md)
-   [Diagnostic Flow (`functional/DIAGNOSTIC_FLOW.md`)](./functional/DIAGNOSTIC_FLOW.md)
-   [DNS Flow (`functional/DNS_FLOW.md`)](./functional/DNS_FLOW.md)
-   [Speedtest Flow (`functional/SPEEDTEST_FLOW.md`)](./functional/SPEEDTEST_FLOW.md)
-   [AI Assistant Functionality (`functional/AI_ASSISTANT.md`)](./functional/AI_ASSISTANT.md)
-   [Settings Functionality (`functional/SETTINGS.md`)](./functional/SETTINGS.md)

### Design System
-   [Material Design 3 Guidelines (`design-system/MD3_GUIDELINES.md`)](./design-system/MD3_GUIDELINES.md)
-   [Reusable Components (`design-system/COMPONENTS.md`)](./design-system/COMPONENTS.md)
-   [Typography (`design-system/TYPOGRAPHY.md`)](./design-system/TYPOGRAPHY.md)
-   [Spacing (`design-system/SPACING.md`)](./design-system/SPACING.md)
-   [Motion (`design-system/MOTION.md`)](./design-system/MOTION.md)
-   [Colors (`design-system/COLORS.md`)](./design-system/COLORS.md)
-   [Chat Patterns (`design-system/CHAT_PATTERNS.md`)](./design-system/CHAT_PATTERNS.md)
-   [Navigation Patterns (`design-system/NAVIGATION.md`)](./design-system/NAVIGATION.md)

### Wireframes
-   [Wireframes and Visual Flows Overview (`wireframes/README.md`)](./wireframes/README.md)

### Operations
-   [Release Process (`operations/RELEASE.md`)](./operations/RELEASE.md)
-   [Versioning Strategy (`operations/VERSIONING.md`)](./operations/VERSIONING.md)
-   [APK Build Process (`operations/APK_BUILD.md`)](./operations/APK_BUILD.md)
-   [Environments (`operations/ENVIRONMENTS.md`)](./operations/ENVIRONMENTS.md)
-   [Deployment (`operations/DEPLOY.md`)](./operations/DEPLOY.md)

### AI Agent Documentation
-   [Agent Workflow (`ai/AGENT_WORKFLOW.md`)](./ai/AGENT_WORKFLOW.md)
-   [Context Policy (`ai/CONTEXT_POLICY.md`)](./ai/CONTEXT_POLICY.md)
-   [Handoff Rules (`ai/HANDOFF_RULES.md`)](./ai/HANDOFF_RULES.md)
-   [Task Breakdown (`ai/TASK_BREAKDOWN.md`)](./ai/TASK_BREAKDOWN.md)
-   [Product Flow for Agents (`ai/PRODUCT_FLOW.md`)](./ai/PRODUCT_FLOW.md)
-   [Engineering Flow for Agents (`ai/ENGINEERING_FLOW.md`)](./ai/ENGINEERING_FLOW.md)
-   [UX Flow for Agents (`ai/UX_FLOW.md`)](./ai/UX_FLOW.md)
-   [Review Flow for Agents (`ai/REVIEW_FLOW.md`)](./ai/REVIEW_FLOW.md)

This documentation is intended to be concise, objective, and easily scannable by AI agents, focusing on architectural, functional, and operational aspects without unnecessary verbosity or code repetition. Implemented, experimental, planned, or legacy statuses will be clearly marked within individual documents. Any information requiring human validation will be explicitly stated.