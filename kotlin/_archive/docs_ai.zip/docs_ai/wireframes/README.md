# Wireframes and Visual Flows

## Objective

This document serves as an index for visual wireframes, user flows, and hierarchy diagrams, mapping them to their expected locations within the `wireframes/` directory.

## Content and Mappings

The `wireframes/` directory is designated for visual documentation. Specific files are expected to reside here:

-   **Markdown Wireframes**: Simple, text-based representations of UI screens.
    -   **Expected Location**: `docs_ai/wireframes/`
    -   **Example Format**: `screen_name.md` (*necessita validação humana para nomeação e existência*)
-   **Flow Diagrams**: Visualizations of user paths through the application.
    -   **Expected Location**: `docs_ai/wireframes/`
    -   **Example Format**: `feature_name_flow.md` (*necessita validação humana*)
-   **Hierarchy Diagrams**: Illustrating screen relationships.
    -   **Expected Location**: `docs_ai/wireframes/`
    -   **Example Format**: `app_structure_hierarchy.md` (*necessita validação humana*)

## Current Status

The `wireframes/` directory has been created, but it currently contains no specific wireframe files. The creation and population of these files require human input based on actual UI designs and user flows.

## Known Risks

-   The absence of actual wireframe files means this documentation is currently a placeholder.
-   The structure and naming conventions for wireframe files need to be defined by a human.
