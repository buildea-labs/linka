# Diagnostic Flow

## Objective

This document details the user flow for diagnostic features, mapping specific components and interactions, including AI-assisted analysis.

## User-Initiated Diagnostics Flow

1.  **Initiation**:
    -   **Entry Point**: User accesses Diagnostics via UI elements in `linka-android-kotlin/featureDiagnostico/ui/DiagnosticScreen.kt` (*inferential path*) or potentially from `featureHome/ui/HomeScreen.kt` (*inferential path*).
    -   **Action**: User taps a "Run Diagnostic" button.

2.  **Data Collection**:
    -   `linka-android-kotlin/featureDiagnostico/` module collects data.
    -   Key data points may include device info (`coreTelephony`/`corePermissions`), network status (`coreNetwork`), performance metrics.

3.  **AI Analysis Integration**:
    -   **Data Transmission**: `featureDiagnostico` (via ViewModel `DiagnosticViewModel.kt` - *inferential path*) uses `coreNetwork` service (`AiDiagnosisService.kt` - *inferential path*) to send data to `cloudflare/ai-diagnosis-worker`.
    -   **AI Processing**: Performed by the external Cloudflare worker.
    -   **Response Reception**: `AiDiagnosisService.kt` receives results.

4.  **Result Processing and Display**:
    -   **ViewModel Update**: `DiagnosticViewModel.kt` processes AI results and updates state.
    -   **UI Presentation**: Composables in `linka-android-kotlin/featureDiagnostico/ui/DiagnosticScreen.kt` display status, issues, AI interpretations, and recommendations.
    -   **History Logging**: Results may be persisted using `coreDatabase/dao/DiagnosticDao.kt` (*inferential path*) and accessed via `featureHistory/`.

## Automated Diagnostics (Potential)

-   **Trigger**: May involve background tasks scheduled via `WorkManager` or `AlarmManager`, potentially managed by a service class in `core*` modules. (*Requires human validation*)
-   **Behavior**: Proactive checks, logging findings in `featureHistory/`.

## Key Files/Modules

-   **`linka-android-kotlin/featureDiagnostico/`**: Main module for diagnostics UI, ViewModel, and logic.
-   **`linka-android-kotlin/coreNetwork/`**: Contains `AiDiagnosisService.kt` for AI worker communication.
-   **`linka-android-kotlin/coreDatabase/`**: Likely contains `DiagnosticDao.kt` for storing history.
-   **`linka-android-kotlin/featureHistory/`**: For accessing historical diagnostic runs.

## Known Risks

-   Specific file paths for ViewModels, DAOs, and service classes are inferential and require human validation.
-   The precise data points collected, AI analysis interpretation logic, and suggested actions need human validation.
-   The implementation of automated diagnostics needs to be confirmed.
