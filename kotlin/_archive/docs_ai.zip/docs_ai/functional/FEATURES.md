# Core Features

## Objective

This document maps the primary features of the Linka Android Kotlin application to their corresponding modules and inferred entry points.

## Features and Module Mappings

The application's functionalities are organized into distinct modules:

-   **Device Management (`featureDevices`)**:
    -   **Module Path**: `linka-android-kotlin/featureDevices/`
    -   **Key Components**: Likely contains UI composables (e.g., `DeviceListScreen.kt`, `DeviceDetailScreen.kt`) and ViewModel (`DeviceViewModel.kt`) for managing devices. (*Inferential file paths*)

-   **Diagnostics (`featureDiagnostico`)**:
    -   **Module Path**: `linka-android-kotlin/featureDiagnostico/`
    -   **Key Components**: UI for running diagnostics (e.g., `DiagnosticScreen.kt`), ViewModel (`DiagnosticViewModel.kt`), logic for data collection and AI interaction initiation. (*Inferential file paths*)

-   **DNS Operations (`featureDns`)**:
    -   **Module Path**: `linka-android-kotlin/featureDns/`
    -   **Key Components**: UI for DNS settings and testing (e.g., `DnsScreen.kt`), ViewModel (`DnsViewModel.kt`). (*Inferential file paths*)

-   **Fiber Optic Specifics (`featureFibra`)**:
    -   **Module Path**: `linka-android-kotlin/featureFibra/`
    -   **Key Components**: UI and logic related to fiber optic connections. Specific files require human validation.

-   **History & Logs (`featureHistory`)**:
    -   **Module Path**: `linka-android-kotlin/featureHistory/`
    -   **Key Components**: UI for displaying logs/history (e.g., `HistoryScreen.kt`), ViewModel (`HistoryViewModel.kt`). (*Inferential file paths*)

-   **Home/Dashboard (`featureHome`)**:
    -   **Module Path**: `linka-android-kotlin/featureHome/`
    -   **Key Components**: Main entry point composable (e.g., `HomeScreen.kt`), ViewModel (`HomeViewModel.kt`), potentially orchestrates navigation and displays overview data. (*Inferential file paths*)

-   **Settings (`featureSettings`)**:
    -   **Module Path**: `linka-android-kotlin/featureSettings/`
    -   **Key Components**: UI for settings management (e.g., `SettingsScreen.kt`), ViewModel (`SettingsViewModel.kt`), interaction with `coreDatastore`. (*Inferential file paths*)

-   **Speedtest (`featureSpeedtest`)**:
    -   **Module Path**: `linka-android-kotlin/featureSpeedtest/`
    -   **Key Components**: UI for initiating and displaying speed tests (e.g., `SpeedtestScreen.kt`), ViewModel (`SpeedtestViewModel.kt`), communication logic via `coreNetwork`. (*Inferential file paths*)

-   **Wi-Fi Management (`featureWifi`)**:
    -   **Module Path**: `linka-android-kotlin/featureWifi/`
    -   **Key Components**: UI for Wi-Fi status and control (e.g., `WifiScreen.kt`), ViewModel (`WifiViewModel.kt`). (*Inferential file paths*)

## Key Files/Modules

-   Each feature corresponds to a directory in `linka-android-kotlin/` (e.g., `featureDevices/`).
-   UI and ViewModel files are typically found in the `ui/` sub-directory within each feature module.

## Known Risks

-   Specific file names and precise paths for UI composables and ViewModels are inferred and require human validation.
-   The exact functionality of `featureFibra` needs to be confirmed.
-   Inter-feature dependencies and how data is shared between modules require detailed validation.
