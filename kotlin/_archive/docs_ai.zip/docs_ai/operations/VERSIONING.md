# Versioning Strategy

## Objective

This document describes the versioning strategy employed for the Linka Android Kotlin application, detailing how version codes and names are managed throughout the development and release lifecycle.

## Versioning Scheme

The application likely follows a modified version of Semantic Versioning or a custom scheme tailored for Android applications, which includes both a `versionName` (user-facing) and a `versionCode` (internal, monotonically increasing).

## Version Codes and Names

-   **`versionName` (e.g., "1.2.0", "0.6.2")**: This is the human-readable version string displayed to users. It typically follows a pattern like `Major.Minor.Patch`.
    -   **Major**: Incremented for significant backward-incompatible changes.
    -   **Minor**: Incremented for new features or backward-compatible changes.
    -   **Patch**: Incremented for backward-compatible bug fixes.
-   **`versionCode` (e.g., 10, 12, 100)**: This is an integer that must increase with each new release. It is used by Google Play Store to determine if an update is available.

## Build Integration

Versioning is integrated into the build process managed by Gradle:

-   **`build.gradle.kts`**: These files likely declare `versionName` and `versionCode` for the application module (`app/build.gradle.kts`). They might read these values from other sources to ensure consistency.
-   **`gradle.properties`**: May store default or base version information.
-   **`scripts/version.ps1`**: This PowerShell script is likely used to programmatically determine or update the `versionCode` and potentially derive `versionName` based on build type, Git tags, or other factors. Its execution is probably tied to build tasks.

## Version Increments

-   **Feature Development**: `versionName` might be in a `Major.Minor.Patch-feature` format (e.g., "0.6.0-dev") during development.
-   **Release Candidates**: Versions might be marked as RC (e.g., "0.6.2-rc.1").
-   **Release Builds**: Stable releases will have a clean `Major.Minor.Patch` format.
-   **`versionCode` Increments**: The `versionCode` is incremented for every single build that is intended for distribution, ensuring a unique identifier for each release artifact. This is often managed by the `scripts/version.ps1` script.

## Key Files/Configuration

-   `app/build.gradle.kts`: Defines `versionName` and `versionCode` or how they are retrieved.
-   `gradle.properties`: May contain base version information.
-   `scripts/version.ps1`: Crucial for programmatic version code and name generation.
-   `apk/releases/` and `apk/_arquivo/`: Store versioned APK artifacts.

## Known Risks

-   The exact logic within `scripts/version.ps1` for determining version codes and names needs human validation to understand how it handles different build types (debug, release, RC) and increments.
-   The strategy for incrementing `versionName` components (Major, Minor, Patch) and ensuring adherence to Semantic Versioning requires confirmation.
-   Potential conflicts or inconsistencies in versioning if multiple developers modify versioning logic without proper coordination need to be managed.
