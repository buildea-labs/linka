# APK Build Process

## Objective

This document describes the process of building Android Application Package (APK) files for the Linka Android Kotlin application, covering debug and release builds, signing, and artifact locations.

## Build Commands

The primary tool for building APKs is **Gradle**, invoked via the Gradle Wrapper (`gradlew`).

-   **Triggering Builds**: Specific Gradle tasks are used to initiate the build process. These are typically defined in the `app/build.gradle.kts` file and can be executed from the project root.

## Build Types

The application supports different build types, each serving a specific purpose:

-   **Debug Builds**:
    -   **Purpose**: For development and internal testing. These builds are typically not optimized for performance and may include debugging tools or extra logging.
    -   **Signing**: Signed with a debug keystore, allowing for easy installation on development devices.
    -   **Location**: May be generated in the `apk/` directory or a build output folder, not typically placed in `apk/releases/`.

-   **Release Builds**:
    -   **Purpose**: For distribution to end-users. These builds are optimized for performance and size.
    -   **Signing**: Must be signed with a release keystore, as detailed in the signing configuration.
    -   **Location**: Generated APKs are placed in the `apk/releases/` directory and archived in `apk/_arquivo/` for historical reference.

## Signing Release APKs

-   **Requirement**: All release builds distributed to app stores or end-users must be cryptographically signed with a release keystore.
-   **Configuration**: Signing details (keystore file path, password, alias, key password) are managed securely.
    -   `key.properties` (and its template `key.properties.template`) is used to store these sensitive details. This file should NOT be committed to version control.
    -   The `build.gradle.kts` file in the `app` module configures Gradle to use these credentials during the release build process.

## Artifacts and Locations

-   **Generated APKs**:
    -   **Release APKs**: Stored in `apk/releases/` for the most recent production-ready builds.
    -   **Archived APKs**: Older release builds and potentially debug builds are archived in `apk/_arquivo/`, organized by version.
-   **Build Outputs**: Intermediate build artifacts and unsigned APKs may be found in the `linka-android-kotlin/build/` directory.

## Key Files/Configuration

-   `app/build.gradle.kts`: Defines build types, product flavors (if any), signing configurations, and APK output paths.
-   `gradlew`: The Gradle wrapper script to execute build tasks.
-   `key.properties` / `key.properties.template`: Stores sensitive keystore credentials.
-   `apk/releases/` and `apk/_arquivo/`: Directories for storing final build artifacts.
-   `local.properties`: May contain paths relevant to the build environment (e.g., SDK location).

## Known Risks

-   The exact Gradle tasks for building debug and release APKs, including any custom tasks, require human validation.
-   The configuration and security of the release keystore management process are critical and need careful human review.
-   The process for archiving and managing older APKs in `apk/_arquivo/` should be well-defined to prevent data loss or confusion.
-   Ensuring that signing configurations are correctly applied for all release builds is paramount.
