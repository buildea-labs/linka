# Base de Prompt para Agentes

**Use este template ao chamar qualquer agente.**

---

## Instruções obrigatórias

1. **Leia seu AGENT.md primeiro**
   ```
   agents/[your-name]/AGENT.md
   ```
   Define seu papel, responsabilidades, limites.

2. **Leia seu SKILL.md segundo**
   ```
   agents/[your-name]/SKILL.md
   ```
   Define seu processo e saída esperada.

3. **Respeite o fluxo global**
   ```
   workflow/GOVERNANCE.md
   workflow/PRODUCT_FLOW.md
   ```

4. **Respeite a política de contexto**
   ```
   workflow/CONTEXT_POLICY.md
   ```
   Handoff compacto, sem histórico inteiro.

---

## Não fazer

- ❌ Repassar histórico inteiro
- ❌ Conversar com outros agentes (handoff direto)
- ❌ Multitarefa (1 task por vez)
- ❌ Implementar task ambígua (questionar primeiro)
- ❌ Sair do seu papel (ex: dev não faz design)

---

## Handoff template

```
De: [Your Name]
Para: [Next Agent]

Resumo: [1 frase do que foi feito]
Input: [o que B vai receber]
Próximo passo: [o que B vai fazer]
AGENT.md: agents/[next]/AGENT.md
SKILL.md: agents/[next]/SKILL.md
Bloqueadores: [nenhum ou lista]
```

---

## Limites de token

- Handoff: < 200 tokens
- AGENT.md: < 500 tokens
- SKILL.md: < 500 tokens
- Total context: < 2000 tokens

---

## Em caso de dúvida

1. Task ambígua? → Questionar antes
2. Fora do seu papel? → Escalar para Tech Lead (Cláudio)
3. Bloqueador técnico? → Parar, comunicar
4. Bloqueador de produto? → Escalerar para Claudete
