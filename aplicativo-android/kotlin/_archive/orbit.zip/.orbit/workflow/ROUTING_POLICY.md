# Política de Roteamento

## Por agente

### Claudete (Product Manager)
- **Quando**: Novo pedido, refinação de scope
- **Modelo**: Claude Sonnet
- **Effort**: Baixo/Médio
- **Handoff para**: Cláudio (após definicao-feature)

### Cláudio (Tech Lead)
- **Quando**: Decomposição técnica, roteamento, decisões arquiteturais
- **Modelo**: Claude Sonnet (ou fallback GPT-5 medium-high)
- **Effort**: Médio/Alto (conforme risco)
- **Roteamento**:
  - Simples → Camilo
  - Complexo → Camila
  - Design → Lia
  - MD3 → Lina
  - Dúvida produto → Claudete

### Camilo (Rapid Engineer)
- **Quando**: Microtask simples (< 2h)
- **Modelo**: GPT-5 mini / Codex mini
- **Effort**: Baixo
- **Critérios**:
  - ✓ 1 arquivo ou mudança fatiada
  - ✓ Pattern claro
  - ✓ < 2h esforço
  - ✗ Arquitetura
  - ✗ Múltiplos módulos
- **Handoff para**: Lina (se UI) → Lia → Merge

### Camila (Principal Engineer)
- **Quando**: Microtask complexa (> 2h ou arquitetural)
- **Modelo**: GPT-5.3 Codex ou Claude Opus
- **Effort**: Alto
- **Critérios**:
  - ✓ Múltiplos módulos
  - ✓ Refactor
  - ✓ Design técnico validado
  - ✗ Task simples
- **Handoff para**: Lina + Lia (review) → Gema (docs)

### Lina (UX Reviewer)
- **Quando**: Feature toca em UI/componentes
- **Modelo**: Claude Haiku
- **Effort**: Baixo
- **Critérios**:
  - ✓ Mudança visual
  - ✓ Novo componente
  - ✗ Fluxo/UX estratégica
- **Handoff para**: Lia (após aprovação)

### Lia (UX Strategist)
- **Quando**: Feature toca em jornada/fluxo
- **Modelo**: Claude Sonnet
- **Effort**: Médio
- **Critérios**:
  - ✓ Novo fluxo conversacional
  - ✓ Navegação
  - ✓ Decisão estratégica
  - ✗ Padrões MD3
- **Handoff para**: Pronto para merge

### Gema (Docs & Release)
- **Quando**: Feature merged ou sprint fechado
- **Modelo**: Gemini Flash / Claude Haiku / GPT-5 mini
- **Effort**: Baixo
- **Tarefas**:
  - documentacao-delta: Após merge
  - notas-release: Após sprint
- **Handoff para**: Nenhum (final)

## Escalonamento

| Situação | Escala para | Ação |
|----------|-------------|------|
| Bloqueador técnico | Cláudio | Parar, comunicar, desbloquear |
| Dúvida produto | Claudete | Questionar, clarificar |
| Redesign profundo | Claudete + PO | Reiniciar cycle |
| MD3 violado | Cláudio | Bloquear merge, reportar |
| KPI impactada | Board | Alinhamento |

## Proibições

❌ Agentes não conversam direto (via handoff)  
❌ Backlog não executa automaticamente (precisa de handoff)  
❌ WIP > 1 por agente  
❌ Repassar histórico inteiro  
❌ Implementar task ambígua (questionar primeiro)
