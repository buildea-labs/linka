# Política de Contexto

## Princípio
Reduzir tokens e contexto desnecessário.

## Regras de handoff
1. **Nunca** repassar histórico inteiro
2. **Sempre** apontar para AGENT.md + SKILL.md específicos
3. **Resumir** em: o que foi feito, próximo passo, bloqueadores
4. **Linkar** para files relevantes (file:line se código)

## Estrutura de handoff
```
De: [Agent A]
Para: [Agent B]

Resumo: [1 frase do que foi feito]
Entrada esperada: [o que B vai receber]
Próximo passo: [o que B vai fazer]
AGENT.md: agents/[b]/AGENT.md
SKILL.md: agents/[b]/SKILL.md
Bloqueadores: [nenhum ou lista]
```

## O que NÃO levar
- ❌ Histórico inteiro
- ❌ Contexto de outras features
- ❌ Discussões/debates passados
- ❌ Código que não será tocado
- ❌ Commits inteiros

## O que LEVAR
- ✅ Link para PR/issue
- ✅ 1-2 frases do contexto
- ✅ Arquivo(s) afetado(s)
- ✅ AC (Acceptance Criteria)
- ✅ Bloqueadores conhecidos

## Exemplo ruim
"Olha, temos um PR aberto desde segunda, o design foi debatido por 2 horas, Lia já revisou 3 vezes, tem um comentário em código do Camilo que questiona a arquitetura, e tem um screenshot anexado... você consegue implementar?"

## Exemplo bom
"PR #123: Novo fluxo de upload. AC: botão + validação + spinner loading. Arquivos: UploadScreen.kt, UploadVM.kt. Bloqueador: Lina aprovou MD3."

## Limite de token
- Handoff < 200 tokens
- AGENT.md + SKILL.md < 500 tokens cada
- Total context por agente < 2000 tokens
