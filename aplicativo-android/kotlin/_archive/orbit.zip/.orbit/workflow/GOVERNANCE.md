# Governança Operacional

## Estrutura
```
Board (Luiz)
├── Product: Claudete
├── Tech: Cláudio
│   ├── Execution: Camilo, Camila
│   └── Docs: Gema
└── UX: Lia (estratégia)
    └── Lina (validação MD3)
```

## Fluxo padrão
1. **Pedido** → Claudete (definicao-feature)
2. **Quebra** → Claudete + Cláudio (quebra-historias)
3. **Roteamento** → Cláudio decide (Camilo vs Camila)
4. **Implementação** → Camilo ou Camila (execucao-microtask)
5. **Review MD3** → Lina (revisao-md3)
6. **Review UX** → Lia (revisao-fluxo-ux)
7. **Merge** → Cláudio aprova
8. **Docs** → Gema (documentacao-delta)
9. **Release** → Gema (notas-release)

## Princípios
- **Compacto**: Handoffs sem histórico inteiro
- **Claro**: Cada agente tem 1 papel, 1 saída
- **Rápido**: Sem conversas paralelas
- **Escalável**: Bloqueadores sobem logo

## Regras obrigatórias
1. Agentes não conversam entre si (handoff direto)
2. Backlog não executa automaticamente
3. WIP = 1 por agente
4. Sem histórico inteiro em handoff
5. Task ambígua = questionar antes de fazer
6. Bloqueador = parar, comunicar, escalar
