# Fluxo de Produto

## De pedido vago a código merged

### 1️⃣ Definição (Claudete)
**Input**: Pedido vago
**Process**: definicao-feature/SKILL.md
**Output**: Feature estruturada (pitch + AC + complexidade)

⏱️ ~1-2h | 📍 agents/claudete/SKILL.md

---

### 2️⃣ Quebra de Histórias (Claudete + Cláudio)
**Input**: Feature aprovada
**Process**: quebra-historias/SKILL.md
**Output**: Stories + microtasks (< 2h cada)

⏱️ ~2-3h | 📍 agents/claudio/SKILL.md

---

### 3️⃣ Roteamento (Cláudio)
**Decision**: Simples → Camilo | Complexo → Camila

```
Critérios:
- < 2h, 1 arquivo, pattern claro → Camilo
- > 2h, múltiplos módulos, design → Camila
- Dúvida → Sempre Camila (seguro)
```

---

### 4️⃣ Implementação (Camilo ou Camila)
**Input**: Microtask clara
**Process**: execucao-microtask/SKILL.md
**Output**: Commit + testes + pronto para review

⏱️ Conforme microtask | 📍 agents/camilo/ ou camila/

---

### 5️⃣ Review MD3 (Lina)
**Input**: PR com mudanças visuais
**Process**: revisao-md3/SKILL.md
**Output**: Aprovado/Rejeito + feedback

⏱️ ~15min | 📍 agents/lina/SKILL.md
Se UI → Segue para Lia

---

### 6️⃣ Review UX (Lia)
**Input**: PR com fluxo/navegação
**Process**: revisao-fluxo-ux/SKILL.md
**Output**: Aprovado/Redesign necessário

⏱️ ~20-30min | 📍 agents/lia/SKILL.md

---

### 7️⃣ Merge (Cláudio)
**Condition**: Todos reviews aprovados
**Action**: Merge + Deploy

---

### 8️⃣ Documentação (Gema)
**Input**: Merged feature
**Process**: documentacao-delta/SKILL.md
**Output**: Docs atualizadas (delta)

⏱️ ~30min-1h | 📍 agents/gema/SKILL.md

---

### 9️⃣ Release (Gema)
**Input**: Sprint completo
**Process**: notas-release/SKILL.md
**Output**: Release notes + versionamento + APK

⏱️ ~1-2h | 📍 agents/gema/SKILL.md
