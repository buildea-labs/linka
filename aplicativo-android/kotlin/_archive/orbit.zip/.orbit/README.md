# Orbit Squad - Operações LINKA

Base operacional enxuta para agentes de IA.

Objetivo: Reduzir contexto repetido, tokens desnecessários e evitar conversas paralelas.

---

## 📁 Estrutura

```
.orbit/
├── agents/                    # 7 agentes + seus papéis + skills
│   ├── claudete/AGENT.md     # Product Manager
│   ├── claudio/AGENT.md      # Tech Lead
│   ├── camilo/AGENT.md       # Rapid Engineer
│   ├── camila/AGENT.md       # Principal Engineer
│   ├── lina/AGENT.md         # UX Reviewer (MD3)
│   ├── lia/AGENT.md          # UX Strategist
│   └── gema/AGENT.md         # Docs & Release
│
├── skills/                    # 7 skills operacionais
│   ├── definicao-feature/
│   ├── quebra-historias/
│   ├── execucao-microtask/
│   ├── revisao-md3/
│   ├── revisao-fluxo-ux/
│   ├── documentacao-delta/
│   ├── notas-release/
│   └── README.md
│
├── workflow/                  # Governança global
│   ├── GOVERNANCE.md         # Estrutura + fluxo padrão
│   ├── PRODUCT_FLOW.md       # 9 passos de produto
│   ├── CONTEXT_POLICY.md     # Handoff compacto
│   └── ROUTING_POLICY.md     # Roteamento de agentes
│
├── archive/                   # Arquivos antigos (não usar)
│
└── AGENT_PROMPT_BASE.md       # Template base para todos agentes
```

---

## 🚀 Como usar

### Iniciar um agente

1. **Aponte para seu AGENT.md**
   ```
   agents/[nome]/AGENT.md
   ```
   Defines papel, responsabilidades, limites.

2. **Aponte para seu SKILL.md**
   ```
   agents/[nome]/SKILL.md
   ```
   Defines processo e saída.

3. **Respeite o fluxo global**
   ```
   workflow/GOVERNANCE.md
   ```

4. **Respeite a política de contexto**
   ```
   workflow/CONTEXT_POLICY.md
   ```
   Handoff compacto, sem histórico inteiro.

### Fazer handoff

Template:
```
De: [Agent A]
Para: [Agent B]

Resumo: [1 frase]
AGENT.md: agents/[b]/AGENT.md
SKILL.md: agents/[b]/SKILL.md
Bloqueadores: [nenhum ou lista]
```

---

## 📊 Fluxo padrão

```
Claudete (definicao-feature)
    ↓
Cláudio (quebra-historias + roteamento)
    ↓
├─ Camilo (execucao-microtask simples)
└─ Camila (execucao-microtask complexa)
    ↓
Lina (revisao-md3)
    ↓
Lia (revisao-fluxo-ux)
    ↓
Cláudio (merge)
    ↓
Gema (documentacao-delta + notas-release)
```

---

## ✅ Agentes

| Agente | Papel | Reporta | Skills |
|--------|-------|---------|--------|
| Claudete | Product Manager | Board | definicao-feature, quebra-historias |
| Cláudio | Tech Lead | Board | quebra-historias, roteamento |
| Camilo | Rapid Engineer | Tech Lead | execucao-microtask (simples) |
| Camila | Principal Engineer | Tech Lead | execucao-microtask (complexa) |
| Lina | UX Reviewer | Tech Lead | revisao-md3 |
| Lia | UX Strategist | Board + Product | revisao-fluxo-ux |
| Gema | Docs & Release | Tech Lead | documentacao-delta, notas-release |

---

## ⚙️ Princípios

- ✓ Compacto (handoff < 200 tokens)
- ✓ Claro (1 papel = 1 saída)
- ✓ Rápido (sem conversas paralelas)
- ✓ Escalável (bloqueadores sobem logo)

---

## 🚫 Proibições

- ❌ Repassar histórico inteiro
- ❌ Agentes conversarem direto (via handoff)
- ❌ Backlog executar automaticamente
- ❌ WIP > 1 por agente
- ❌ Task ambígua (questionar antes)

---

## 📚 Para explorar

- `agents/*/AGENT.md` — Papéis específicos
- `agents/*/SKILL.md` — Skills por agente
- `workflow/GOVERNANCE.md` — Estrutura completa
- `workflow/ROUTING_POLICY.md` — Decisões de roteamento
- `skills/*/SKILL.md` — Processos operacionais

---

## 🔄 Atualizações

Para atualizar esta base operacional:
1. Alterar AGENT.md / SKILL.md do agente específico
2. Atualizar workflow/ se fluxo mudar
3. Avisar todos agentes das mudanças

---

**Última atualização**: 2026-05-13
