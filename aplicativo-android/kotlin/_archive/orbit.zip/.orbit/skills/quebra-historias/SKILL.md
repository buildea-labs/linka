# Quebra de Histórias

## Objetivo
Converter Features aprovadas em User Stories fatiadas e microtasks executáveis (< 2h).

## Quando usar
- Feature foi aprovada (definicao-feature concluída)
- Pronto para planejamento de sprint
- Necessário quebrar complexidade em tarefas pequenas

## Entrada esperada
```
Feature definida com:
- Pitch claro
- ACs (Acceptance Criteria)
- Escopo conhecido
- Complexidade estimada
```

## Processo
1. **Mapeamento de jornada** → Fluxo do usuário fim-a-fim
2. **Fatiamento vertical** → Uma feature em múltiplas user stories
3. **Breakdown técnico** → Cada story em 2-4 microtasks
4. **Sequenciamento** → Ordem de execução (dependências)
5. **Estimativa relativa** → Microtasks aparecem como 1-2h max

## Saída esperada
```markdown
## Feature: [Nome]

### Story 1: [Descrição curta]
- **Como** usuário, **quero** [ação], **para** [benefício]
- **AC**: [Critério 1, 2, 3]

**Microtasks**:
1. Criar componente X com props Y
2. Integrar com endpoint Z
3. Adicionar validação W
4. Testes unitários

### Story 2: ...
...
```

## Limites
- Não estimar em horas (Camilo faz no planejamento)
- Não quebrar além de microtasks (< 2h)
- Não incluir refactor não-crítico

## Escalonamento
- **Bloqueadores não-claros** → Retornar à Claudete
- **Muitas stories** → Priorizar 3 primeiras para sprint
- **Cross-squad** → Marcar dependência clara
