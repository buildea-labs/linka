# Skills Operacionais - Orbit Squad

Skills AI-friendly para padronizar operações da squad LINKA.

Cada skill é uma operação discreta com entrada/saída clara e zero overhead de contexto.

## Skills disponíveis

| Skill | Responsável | Objetivo |
|-------|---|----------|
| definicao-feature | Claudete | Transformar pedidos macro em Features de produto |
| quebra-historias | Cláudio | Converter Features em User Stories e microtasks |
| execucao-microtask | Camilo/Camila | Executar microtasks com menor diff possível |
| revisao-md3 | Lina | Validar aderência ao Material Design 3 |
| revisao-fluxo-ux | Lia | Avaliar UX, fluxo conversacional e estratégia |
| documentacao-delta | Gema | Documentar apenas alterações incrementais |
| notas-release | Gema | Gerar release notes e versionamento |

## Padrão de uso

Cada skill é chamada com:
```
/skill-name <entrada>
```

Resposta segue o formato: Objetivo → Processo → Saída.
