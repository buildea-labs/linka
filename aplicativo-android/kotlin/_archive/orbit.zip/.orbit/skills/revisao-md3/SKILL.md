# Revisão Material Design 3

## Objetivo
Validar aderência ao MD3 (colors, typography, spacing, components) antes de merge.

## Quando usar
- Feature/microtask toca em UI ou componentes
- Mudanças em Compose, cores ou tipografia
- Antes de revisao-fluxo-ux ou merge

## Entrada esperada
```
Pull Request ou branch com:
- Componentes Compose novos/modificados
- Mudanças visuais
- Screenshots (recomendado)
```

## Processo
1. **Tokens** → Cores, tamanhos, espaçamento usam design-tokens do projeto?
2. **Tipografia** → Headlines, body, labels seguem escala MD3?
3. **Componentes** → Buttons, cards, inputs seguem Compose Material?
4. **Estados** → Hover, disabled, error, loading implementados?
5. **Acessibilidade** → Contraste, touch targets (48dp min), navegação

## Saída esperada
```markdown
### Revisão MD3 ✓/✗

**Tokens**: ✓ Usando design-tokens corretos
**Tipografia**: ✓ Segue escala do projeto
**Componentes**: ✗ Button custom deveria usar M3Button
**Estados**: ✓ Disabled e loading OK
**A11y**: ⚠ Contraste baixo em [elemento], ajustar cor

**Aprovado**: [Sim | Com ajustes mínimos | Rejeitar]
```

## Limites
- Não redesenhar (isso é revisao-fluxo-ux)
- Não avaliar UX ou fluxo (passa para Lia)
- Não refatorar código não-UI

## Escalonamento
- **Violações MD3 críticas** → Bloquear merge
- **Design-token novo necessário** → Reportar para Design System owner
- **Ambiguidade em padrão** → Questionar Lia (product design)
