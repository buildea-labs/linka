# Notas de Release

## Objetivo
Gerar release notes e versionamento enxuto após série de features/fixes validados.

## Quando usar
- Sprint/ciclo concluído com features prontas
- Pronto para build de release
- Necessário comunicar mudanças a usuários/stakeholders

## Entrada esperada
```
Sprint resumido com:
- Features merged (com descrição de valor)
- Bugs críticos corrigidos
- Documentação atualizada
- Versão atual do app
```

## Processo
1. **Coleta** → PRs merged, features entregues, bugfixes
2. **Categorização** → Features | Melhorias | Bugfixes
3. **Redação** → User-facing (benefício, não implementação técnica)
4. **Versionamento** → SemVer (major.minor.patch) baseado em mudanças
5. **Finalizacao** → CHANGELOG.md + versão no código + comunicado

## Saída esperada
```markdown
# Release Notes v1.2.0

**Features**:
- 📸 Nova tela de galeria com seleção múltipla
- 🔐 Autenticação com biometria (face/fingerprint)

**Melhorias**:
- Performance de sync +40% mais rápido
- Novos ícones no menu principal

**Bugfixes**:
- Corrige crash ao abrir câmera no Android 11
- Input de mensagens não perde texto ao girar tela

**Download**: [Link APK] | Release Date: [Data]
```

## Limites
- Não incluir detalhes técnicos (é para usuários)
- Não repetir changelog (diferente, é resumido)
- Não fazer spin/marketing agressivo
- Não prometer features que ainda testando

## Escalonamento
- **Versão ambígua** → Questionar Tech Lead + PO
- **Breaking change** → Major version + documentação de migração
- **Segurança crítica** → Release imediata, comunicado urgente
