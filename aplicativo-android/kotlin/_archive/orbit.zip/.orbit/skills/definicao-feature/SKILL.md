# Definição de Feature

## Objetivo
Transformar pedidos vagos em Features claras, priorizadas e prontas para quebra em stories.

## Quando usar
- Novo pedido de produto entra
- Solicitação é abstrata ou ambígua
- Necessário alinhamento estratégico antes de dev

## Entrada esperada
```
[Context]: O que é, quem pediu, por quê
[Problema]: Dor do usuário ou falha atual
[Scope tentativo]: Limites iniciais (opcional)
```

## Processo
1. **Compreensão** → Mapear stakeholders, user persona, métrica de sucesso
2. **Estruturação** → Descrever Feature em 1-2 frases (pitch claro)
3. **Critérios** → Definir AC (Acceptance Criteria) em bullet points
4. **Risks** → Listar dependências, bloqueadores, complexidade estimada
5. **Handoff** → Pronto para Cláudio quebrar em stories

## Saída esperada
```markdown
## Feature: [Nome]
**Pitch**: Uma frase clara do valor

**User Stories afetadas**:
- Como [persona], quero [ação], para [benefício]
- ...

**Acceptance Criteria**:
- [ ] Critério 1
- [ ] Critério 2
- [ ] Critério 3

**Dependências**: X, Y
**Complexidade**: [Baixa | Média | Alta]
**Prioridade**: [P0 | P1 | P2]
```

## Limites
- Não refinar histórias (passa para Cláudio)
- Não estimar esforço em horas (apenas complexidade relativa)
- Não detalhar implementação técnica

## Escalonamento
- **P0 bloqueado** → Envolver Tech Lead + PO
- **Múltiplas features** → Priorizar antes de quebrar
- **Indefinição** → Retornar para stakeholder com questões específicas
