# Revisão Fluxo UX

## Objetivo
Avaliar experiência do usuário, fluxo conversacional e aderência à estratégia de produto.

## Quando usar
- Feature toca em jornada do usuário
- Novo fluxo conversacional ou de interação
- Mudanças em navegação ou ações primárias
- Antes de merge (após revisao-md3)

## Entrada esperada
```
PR com:
- Descrição do fluxo novo
- Persona impactada
- Screenshots ou prototipo
- AC mapeado
```

## Processo
1. **Jornada** → Caminho do usuário do início ao fim faz sentido?
2. **Clareza** → Labels, mensagens, CTAs são claros?
3. **Eficiência** → Mínimo de taps/cliques para objetivo?
4. **Consistência** → Segue padrões do app já estabelecidos?
5. **Estratégia** → Alinhado com goals de produto e KPIs?

## Saída esperada
```markdown
### Revisão UX ✓/✗

**Jornada**: ✓ Lógica clara, reduz atrito
**Clareza**: ✗ CTA "Next" deveria ser "Send photo"
**Eficiência**: ✓ 2 taps ao invés de 4
**Consistência**: ⚠ Pattern diferente de outras screens, justificar?
**Estratégia**: ✓ Aumenta conversão (métrica: X)

**Aprovado**: [Sim | Com ajustes | Rejeitar]
**Notas para implementador**: [Mudanças requeridas]
```

## Limites
- Não validar implementação técnica (responsabilidade de code review)
- Não validar MD3 (passa para Lina antes)
- Não especificar pixels (deixar para designer)

## Escalonamento
- **Redesign profundo necessário** → Envolver Design
- **Conflito com estratégia** → Alinhamento com PO + Claudete
- **Métrica/KPI impactada** → Discussão com Analytics
