# Execução de Microtask

## Objetivo
Executar microtasks isoladas com mudanças mínimas, testes e pronto para review.

## Quando usar
- Microtask está clara (< 2h esforço)
- Código foi quebra-historias
- Pronto para implementação imediata

## Entrada esperada
```
Microtask com:
- Descrição clara da ação
- Arquivo(s) afetado(s)
- AC (se houver)
- Nenhuma bloqueador pendente
```

## Processo
1. **Contexto** → Ler arquivo atual, entender padrão do projeto
2. **Implementação** → Mudança mínima, sem refactor adicional
3. **Testes** → Unitários para lógica nova, verificação manual de UI
4. **Linting** → Passar em checks do projeto
5. **Commit** → Mensagem clara e breve

## Saída esperada
```
Commit com:
- Código funcional
- Testes passando
- 1 arquivo ou mudança fatiada
- Pronto para review (revisao-md3 ou revisao-fluxo-ux)
```

## Limites
- Não fazer refactor além do necessário
- Não mudar múltiplos arquivos (respeitar microtask)
- Não reescrever testes existentes
- Não tocar em areas não-listadas

## Escalonamento
- **Bloqueador descoberto** → Pausar, comunicar, retornar story
- **AC não-clara** → Questionar antes de implementar
- **Redesign necessário** → Escalar para Lia (revisao-fluxo-ux)
