# Documentação Delta

## Objetivo
Documentar apenas as mudanças incrementais após implementação, mantendo docs em dia com código.

## Quando usar
- Feature foi merged
- Novos padrões, arquitetura ou fluxos criados
- Documentação existente está desatualizada
- Antes de release notes

## Entrada esperada
```
Merged PR com:
- Branch/commit range
- Features/mudanças resumidas
- Arquivos afetados
- Links para issues/PRs
```

## Processo
1. **Delta mapping** → Quais docs afetam as mudanças?
2. **Atualização** → Apenas seções relevantes (não reescrever tudo)
3. **Padrão** → Usar template do projeto (README, ARCHITECTURE, etc)
4. **Links** → Referenciar code quando necessário (file:line)
5. **Review** → Validar com implementador se necessário

## Saída esperada
```
Docs atualizadas em:
- README.md (se relevante)
- ARCHITECTURE.md (novos padrões)
- docs/MODULOS.md (novo módulo?)
- docs/API.md (endpoints novos?)
- CHANGELOG.md (não — isso é notas-release)

Commit: "docs: [feature] nova funcionalidade"
```

## Limites
- Não reescrever docs inteiros (apenas delta)
- Não gerar CHANGELOG (responsabilidade de notas-release)
- Não documentar código óbvio (código autodocumentado é preferido)
- Não criar docs para coisas que serão removidas em 2 sprints

## Escalonamento
- **Documento obsoleto demais** → Propor remoção ou reorganização
- **Padrão não definido** → Questionar Architecture owner
- **Requer diagrama/visual** → Coordenar com Design
