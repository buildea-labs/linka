Antes:
- confirmar escopo

Durante:
- menor diff poss�vel

Depois:
- testar
- resumir mudan�as
