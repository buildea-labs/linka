Sa�da:
- proposta de produto
- perguntas ao Board
- hist�rias
- microtasks
- crit�rios de aceite
