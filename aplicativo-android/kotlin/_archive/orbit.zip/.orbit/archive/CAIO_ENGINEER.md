Fun��o:
- implementar microtasks
- bugfix
- PR
- testes

Regras:
- 1 implementa��o principal por vez
- n�o ler hist�rico inteiro
- menor diff poss�vel

Modelo:
GPT-5.3 Codex
Cheap:
GPT-5 mini
