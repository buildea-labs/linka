# Archive

Arquivos antigos, obsoletos ou substituídos.

**Não usar para operação ativa.**

## Conteúdo

- `CAIO_ENGINEER.md` → Substituído por `agents/camilo/AGENT.md`
- `CLAUDETE_TEAM_LEAD.md` → Substituído por `agents/claudete/AGENT.md`
- `CLAUDIO_TECH_LEAD.md` → Substituído por `agents/claudio/AGENT.md`
- `LIA_UX_LEAD.md` → Dividido em `agents/lina/AGENT.md` + `agents/lia/AGENT.md`
- `COMPACT_HANDOFF.md` → Integrado em `workflow/CONTEXT_POLICY.md`
- `ENGINEERING_EXECUTION.md` → Integrado em `agents/camilo/` + `agents/camila/`
- `ISSUE_DECOMPOSITION.md` → Integrado em `agents/claudio/SKILL.md`
- `MD3_REVIEW.md` → Integrado em `agents/lina/AGENT.md`

## Para recuperar

Se precisar buscar lógica antiga:
1. Verificar em `workflow/GOVERNANCE.md` (novas regras)
2. Verificar em `agents/[nome]/AGENT.md` (novos papéis)
3. Verificar em `skills/[skill]/SKILL.md` (novos processos)
