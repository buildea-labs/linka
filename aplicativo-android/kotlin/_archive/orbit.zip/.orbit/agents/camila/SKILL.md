# Skills - Camila

## execucao-microtask
Executar microtasks isoladas com mudanças mínimas.

**Gatilho**: Task complexa/arquitetural (> 2h ou cross-module)
**Input**: Descrição + Design técnico validado + Contexto
**Output**: Código completo + Testes + Documentação

📍 Ver: `skills/execucao-microtask/SKILL.md`

---

## Variante Camila (vs Camilo)
- Múltiplos módulos afetados
- Refactor de subsistema
- Mudança arquitetural
- Performance/Segurança crítica
- Integração complexa

---

## Handoff
Após implementar:
1. Documentar mudanças arquiteturais (documentacao-delta)
2. Passar para Lina + Lia (review UI/UX)
3. Cláudio faz code review técnico
4. Pronto para merge

---

## Não fazer
- Implementar sem design validado
- Multitarefa (foco total)
- Task simples (roteia para Camilo)
