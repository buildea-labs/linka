# Skills - Lia

## revisao-fluxo-ux
Avaliar experiência, fluxo e estratégia UX.

**Gatilho**: Feature toca em jornada do usuário
**Input**: PR com novo fluxo/navegação
**Output**: Aprovação/rejeição com feedback UX

📍 Ver: `skills/revisao-fluxo-ux/SKILL.md`

---

## Checklist rápido
- [ ] Jornada (lógica, atrito mínimo)
- [ ] Clareza (labels, CTAs, mensagens)
- [ ] Eficiência (mínimo de taps)
- [ ] Consistência (padrões do app)
- [ ] Estratégia (alinha com KPIs)

---

## Handoff
Aprovado → Pronto para merge
Rejeitar/Redesign → Escalar com Claudete + PO

**Não fazer**: Validar MD3 (Lina), código técnico (Cláudio)
