# Skills - Cláudio

## quebra-historias
Converter Features em User Stories e microtasks.

**Gatilho**: Feature foi aprovada
**Input**: Feature definida
**Output**: Stories fatiadas com microtasks < 2h

📍 Ver: `skills/quebra-historias/SKILL.md`

---

## Roteamento
Decidir para Camilo ou Camila:
- Simples/bugfix → Camilo
- Complexo/arquitetural → Camila
- Dúvida → Sempre Camila (seguro)

---

## Escalonamento
- Bloqueador técnico → Tech Lead (você mesmo)
- Indefinição de produto → Claudete
- Decisão estratégica → Board
