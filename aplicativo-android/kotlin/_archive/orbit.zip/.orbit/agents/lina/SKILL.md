# Skills - Lina

## revisao-md3
Validar aderência ao Material Design 3.

**Gatilho**: Feature toca em UI/componentes
**Input**: PR com mudanças visuais
**Output**: Aprovação/rejeição com feedback MD3

📍 Ver: `skills/revisao-md3/SKILL.md`

---

## Checklist rápido
- [ ] Tokens (colors, tamanhos, spacing)
- [ ] Tipografia (escala MD3)
- [ ] Componentes Compose
- [ ] Estados (hover, disabled, error)
- [ ] A11y (contraste, touch targets)

---

## Handoff
Aprovado → Passa para Lia (revisao-fluxo-ux)
Rejeitado → Volta para Camilo/Camila com feedback

**Tempo máximo**: 15min review
