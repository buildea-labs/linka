# Skills - Claudete

## definicao-feature
Transformar pedidos vagos em Features claras e priorizadas.

**Gatilho**: Novo pedido de produto entra
**Input**: Context + Problema + Scope tentativo
**Output**: Feature estruturada com AC, risks, complexidade

📍 Ver: `skills/definicao-feature/SKILL.md`

---

## quebra-historias
Converter Features em User Stories e microtasks.

**Gatilho**: Feature foi aprovada
**Input**: Feature definida
**Output**: Stories fatiadas com microtasks < 2h

📍 Ver: `skills/quebra-historias/SKILL.md`
