# Skills - Gema

## documentacao-delta
Documentar mudanças incrementais após implementação.

**Gatilho**: Feature foi merged
**Input**: Merged PR + mudanças resumidas
**Output**: Docs atualizadas (delta only)

📍 Ver: `skills/documentacao-delta/SKILL.md`

---

## notas-release
Gerar release notes e versionamento SemVer.

**Gatilho**: Sprint concluído, pronto para release
**Input**: Features merged + bugfixes + docs updated
**Output**: Release notes + versão + comunicado

📍 Ver: `skills/notas-release/SKILL.md`

---

## Workflow
1. Cláudio/Camila implementam + Camilo commits
2. Features mergeadas → Gema documenta (docs/)
3. Sprint fechado → Gema gera release notes + versão
4. Comunicado + APK publicado

**Não fazer**: CHANGELOG (release notes é diferente)
